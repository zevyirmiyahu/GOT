package game.graphics;

public class Sprite {
  public final int SIZE; // set sizes of sprite, final means it can only be declared once/its a constant/it doesnt vary
  private int x, y;
  private int width, height;
  public int[] pixels;
  protected SpriteSheet sheet;
  

  // *Creates new static instance of the sprite class, to access from other class simply type Sprite.grass, but other variables in sprite class are NOT static so this has all unique variables
/*public static Sprite grass = new Sprite(16, 0, 0, SpriteSheet.spawn_level); // add spritesheet and delete null This line creates the sprite, VERY IMPORTANT
  public static Sprite grass2 = new Sprite(16, 1, 0, SpriteSheet.objects);
  public static Sprite rock = new Sprite(16, 2, 0, SpriteSheet.objects); // loads an 8 * 8 square ( 16 pixels at coordinates x=8 and y=0)
  public static Sprite flower = new Sprite(16, 3, 0, SpriteSheet.objects);
  public static Sprite water = new Sprite(16, 4, 0, SpriteSheet.objects); */

  public static Sprite voidSprite = new Sprite(16, 0x1B87E0); //Size 16 pixels and blue

  //SPAWN_LEVEL SPRITES HERE:
  public static Sprite spawn_grass1 = new Sprite(16, 0, 0, SpriteSheet.spawn_level);
  public static Sprite spawn_grass2 = new Sprite(16, 1, 0, SpriteSheet.spawn_level);
  public static Sprite spawn_grass3 = new Sprite(16, 2, 0, SpriteSheet.spawn_level);
  public static Sprite spawn_grass4 = new Sprite(16, 3, 0, SpriteSheet.spawn_level);
  public static Sprite spawn_chickenGrass = new Sprite(16, 11, 1, SpriteSheet.town_level); // Tile used for chicken area
  public static Sprite spawn_grassCollidor = new Sprite(16, 12, 1, SpriteSheet.town_level); //Collidor for chicken area walls
  
  public static Sprite spawn_rock = new Sprite(16, 0, 1, SpriteSheet.spawn_level);
  
  public static Sprite spawn_flower = new Sprite(16, 1, 1, SpriteSheet.spawn_level);
  public static Sprite spawn_flower_pink = new Sprite(16, 12, 0, SpriteSheet.town_level);
  
  public static Sprite spawn_sand = new Sprite(16, 10, 0, SpriteSheet.town_level);
  
  public static Sprite spawn_water1 = new Sprite(16, 2, 1, SpriteSheet.spawn_level);
    
  public static Sprite spawn_water_river = new Sprite(16, 8, 0, SpriteSheet.town_level);
  public static Sprite spawn_water_corner_TL = new Sprite(16, 8, 1, SpriteSheet.town_level);
  public static Sprite spawn_water_corner_TR = new Sprite(16, 9, 1, SpriteSheet.town_level);
  public static Sprite spawn_water_corner_BR = new Sprite(16, 9, 2, SpriteSheet.town_level);
  public static Sprite spawn_water_corner_BL = new Sprite(16, 8, 2, SpriteSheet.town_level);
  
  public static Sprite spawn_water_side_l = new Sprite(16, 0, 1, SpriteSheet.town_level);
  public static Sprite spawn_water_side_r = new Sprite(16, 1, 1, SpriteSheet.town_level);
  public static Sprite spawn_water_side_t = new Sprite(16, 2, 1, SpriteSheet.town_level);
  public static Sprite spawn_water_side_b = new Sprite(16, 2, 2, SpriteSheet.town_level);
  
  public static Sprite spawn_water_edge_tl = new Sprite(16, 0, 2, SpriteSheet.town_level);
  public static Sprite spawn_water_edge_tr = new Sprite(16, 1, 2, SpriteSheet.town_level);
  public static Sprite spawn_water_edge_bl = new Sprite(16, 0, 3, SpriteSheet.town_level);
  public static Sprite spawn_water_edge_br = new Sprite(16, 1, 3, SpriteSheet.town_level);
  
  public static Sprite spawn_cliff = new Sprite(16, 3, 2, SpriteSheet.town_level);
  public static Sprite spawn_cliff_t = new Sprite(16, 6, 2, SpriteSheet.town_level);
  public static Sprite spawn_cliff_b = new Sprite(16, 4, 2, SpriteSheet.town_level);
  public static Sprite spawn_cliff_l = new Sprite(16, 5, 2, SpriteSheet.town_level);
  public static Sprite spawn_cliff_r = new Sprite(16, 7, 2, SpriteSheet.town_level);
  
  public static Sprite spawn_cliff_corner_tl = new Sprite(16, 6, 3, SpriteSheet.town_level); //top left corner piece
  public static Sprite spawn_cliff_corner_tr = new Sprite(16, 7, 3, SpriteSheet.town_level); // top right
  public static Sprite spawn_cliff_corner_bl = new Sprite(16, 6, 4, SpriteSheet.town_level);
  public static Sprite spawn_cliff_corner_br = new Sprite(16, 7, 4, SpriteSheet.town_level);
  
  public static Sprite spawn_cliff_edge_tl = new Sprite(16, 5, 4, SpriteSheet.town_level); //top left edge piece
  public static Sprite spawn_cliff_edge_tr = new Sprite(16, 4, 4, SpriteSheet.town_level); // top right
  public static Sprite spawn_cliff_edge_bl = new Sprite(16, 5, 3, SpriteSheet.town_level); // bottom left
  public static Sprite spawn_cliff_edge_br = new Sprite(16, 4, 3, SpriteSheet.town_level);

  
  public static Sprite spawn_brick1 = new Sprite(16, 0, 2, SpriteSheet.spawn_level); //Castle wall
  public static Sprite spawn_brick2 = new Sprite(16, 1, 2, SpriteSheet.spawn_level);
  public static Sprite spawn_brick3 = new Sprite(16, 2, 2, SpriteSheet.spawn_level);
  
  //House pieces
  public static Sprite spawn_door = new Sprite(16, 15, 0, SpriteSheet.town_level);
  public static Sprite spawn_wall = new Sprite(16, 14, 0, SpriteSheet.town_level);
  public static Sprite spawn_wood_floor = new Sprite(16, 13, 0, SpriteSheet.town_level);
  
  public static Sprite spawn_crack1 = new Sprite(16, 3, 2, SpriteSheet.spawn_level);
  public static Sprite spawn_crack2 = new Sprite(16, 0, 3, SpriteSheet.spawn_level);

  public static Sprite mainZone = new Sprite(16, 14, 1, SpriteSheet.town_level); //sprite of a door
  public static Sprite pamZone = new Sprite(16, 13, 1, SpriteSheet.town_level); //used to enter pams house

  //PLAYER SPRITES HERE:

  /*
  // LOADS SPRITE FROM 4 PIECES
  public static Sprite player0 = new Sprite(16, 0, 0, SpriteSheet.objects); //loads sprite from 4 pieces
  public static Sprite player1 = new Sprite(16, 0, 1, SpriteSheet.objects);
  public static Sprite player2 = new Sprite(16, 1, 0, SpriteSheet.objects);
  public static Sprite player3 = new Sprite(16, 1, 1, SpriteSheet.objects);
  */
  // LOADS SPRITE FROM 1 PIECE 32 X 32 PIXELS
/* public static Sprite player_downward = new Sprite(32, 0, 0, SpriteSheet.objects); // *IMPORTANT since pixel size is double x and y need to be half to compensate, for 32 size rendering
  public static Sprite player_forward = new Sprite(32, 0, 1, SpriteSheet.objects);
  public static Sprite player_left = new Sprite(32, 0, 2, SpriteSheet.objects);
  public static Sprite player_right = new Sprite(32, 0, 3, SpriteSheet.objects); */

  // Sprite movement pieces
 /* public static Sprite player_downward_1 = new Sprite(32, 1, 0, SpriteSheet.objects);
  public static Sprite player_downward_2 = new Sprite(32, 2, 0, SpriteSheet.objects);
  public static Sprite player_forward_1 = new Sprite(32, 1, 1, SpriteSheet.objects);
  public static Sprite player_forward_2 = new Sprite(32, 2, 1, SpriteSheet.objects);
  public static Sprite player_left_1 = new Sprite(32, 1, 2, SpriteSheet.objects);
  public static Sprite player_left_2 = new Sprite(32, 2, 2, SpriteSheet.objects);
  public static Sprite player_right_1 = new Sprite(32, 1, 3, SpriteSheet.objects);
  public static Sprite player_right_2 = new Sprite(32, 2, 3, SpriteSheet.objects); */
  
  //Sprite Buildings
  public static Sprite house = new Sprite(96, 0, 0, SpriteSheet.house);
  public static Sprite farmHouse = new Sprite(96, 0, 0, SpriteSheet.farmHouse);
  
  //Sprite Scenery
  public static Sprite farmField = new Sprite(64, 80, SpriteSheet.farmField);
  
  public static Sprite player = new Sprite(32, 0, 0, SpriteSheet.player_down);
  public static Sprite playerSword = new Sprite(32, 0, 0, SpriteSheet.playerSword_down);
  public static Sprite playerAttack = new Sprite(32, 0, 0, SpriteSheet.playerAttack_down);
  public static Sprite playerAttackStanding = new Sprite(32, 0, 0, SpriteSheet.playerAttackStanding_down);
  public static Sprite dummy = new Sprite(32, 0, 0, SpriteSheet.dummy_down);
  public static Sprite chaser = new Sprite(32, 0, 0, SpriteSheet.chaser_down);
  public static Sprite mummy = new Sprite(16, 0, 0, SpriteSheet.mummy_down);
  public static Sprite goon = new Sprite(32, 0, 0, SpriteSheet.goon_down);
  public static Sprite pam = new Sprite(32, 0, 0, SpriteSheet.pam_down);
  public static Sprite chicken = new Sprite(16, 32, SpriteSheet.chicken_down);
  public static Sprite deadChicken = new Sprite(16, 16, SpriteSheet.deadChicken);
  
  //PROJECTILE SpriteSheet
  public static Sprite wizard_projectile = new Sprite(16, 0, 7, SpriteSheet.items);
  public static Sprite wizard_projectile2 = new Sprite(16, 2, 8, SpriteSheet.items);
  public static Sprite projectile_ax = new Sprite(16, 1, 8, SpriteSheet.items);

  //Particles
  public static Sprite particle_normal = new Sprite(3, 0xfc60ac); //first number is the size and second number is the color

  //CONSTRUCTORS
  protected Sprite(SpriteSheet sheet, int width, int height) {
    if(width == height) SIZE = width;
    else SIZE = -1;
    // SAME AS ABOVE IF & ELSE STATEMENTS:  SIZE = (width == height) ? width : -1;
    this.width = width;
    this.height = height;
    this.sheet = sheet;
  }
  
  
  public Sprite(int size, int x, int y, SpriteSheet sheet) { //Sprite class Constructor
    SIZE = size;
    this.width = size;
    this.height = size;
    pixels = new int[SIZE * SIZE];
    this.x = x * size; // locates the sprite and sets proper x location of the target sprite
    this.y = y * size;
    this.sheet = sheet;
    load();
  }
  
  public Sprite(int width, int height, SpriteSheet sheet) {
	  SIZE = width * height;
	  this.width = width;
	  this.height = height;
	  pixels = new int[SIZE];
	  this.x = x * width;
	  this.y = y * height;
	  this.sheet = sheet;
	  load();
  } 

  public Sprite(int width, int height, int color) { // square sprite
    SIZE = -1; //won't be using
    this.width = width;
    this.height = height;
    pixels = new int[width * height];
    setColor(color);
  }

  public Sprite(int size, int color) { //Constructor for voidSprite
    SIZE = size;
    this.width = size;
    this.height = size;
    pixels = new int[SIZE*SIZE];
    setColor(color); //calls set color method
  }

  public Sprite(int[] pixels, int width, int height) {
    SIZE = (width == height) ? width : -1;
    this.width = width;
    this.height = height;
    //Can use the below arraycopy as an alternative to the below for loop for copying elements of an array
    //System.arraycopy(arg0, arg1, arg2, arg3, arg4); arg0 = source of what your copy from, arg1 is position to start copying from, arg2 destination to copy into, arg3 is destination position you want it to paste at, arg4 is the length of array
    this.pixels = new int[pixels.length]; //MUST copy each individual integer to array otherwise java doesn't update the pixel reference, in particular when rendering seperate character sprites to the screen
    for(int i = 0; i < pixels.length; i++) {
    	this.pixels[i] = pixels[i];
    }
  }
  
  public static Sprite rotate(Sprite sprite, double angle) {
	  return new Sprite(rotate(sprite.pixels, sprite.width, sprite.height, angle), sprite.width, sprite.height);
  }

  //Method used to copy pixels of the sprite to be rotated and  copy them to new array and rotate those pixels
  private static int[] rotate(int[] pixels, int width, int height, double angle) { //width and height here are of the Sprite
	  int[] result = new int[width * height];
	  
	  double nx_x = rot_x(-angle, 1.0, 0.0); //new x coordinate, angle is negative since rotation is clockwise
	  double nx_y = rot_y(-angle, 1.0, 0.0);
	  
	  double ny_x = rot_x(-angle, 0.0, 1.0);
	  double ny_y = rot_y(-angle, 0.0, 1.0);
	  
	  double x0 = rot_x(-angle, -width / 2.0, -height / 2.0) + width / 2.0; //Initial x
	  double y0 = rot_y(-angle, -width / 2.0, -height / 2.0) + height / 2.0; // Initial y
	  
	  for(int y = 0; y < height; y++) {
		  double x1 = x0;
		  double y1 = y0;
		  for(int x = 0 ; x < width; x++) {
			  int xx = (int) x1;
			  int yy = (int) y1;
			  int col = 0;
			  if(xx < 0 || xx >= width || yy < 0 || yy >= height) col = 0;//0xffff00ff;
			  else col = pixels[xx + yy * width];
			  result[x + y * width] = col;
			  x1 += nx_x; //increment based on the direction
			  y1 += nx_y;
		  }
		  x0 += ny_x;
		  y0 += ny_y;
	  }
	  
	  return result;
  }
  
  private static double rot_x(double angle, double x, double y) {
	  double cos = Math.cos(angle - Math.PI / 2); //rotates 90 degrees clockwise
	  double sin = Math.sin(angle - Math.PI / 2);
	  return x * cos + y * -sin;
  }
  
  private static double rot_y(double angle, double x, double y) {
	  double cos = Math.cos(angle - Math.PI / 2);
	  double sin = Math.sin(angle - Math.PI / 2);
	  return x * sin + y * cos;
  }
  

  public static Sprite[] split(SpriteSheet sheet) { //this method splits an spritesheet into seperate sprites. Used to obtain individual characters
	  int amount = (sheet.getWidth() * sheet.getHeight()) / (sheet.SPRITE_WIDTH * sheet.SPRITE_HEIGHT); //area of whole sprite sheet divided by area of a single sprite
	  Sprite[] sprites = new Sprite[amount];
	  int[] pixels = new int[sheet.SPRITE_WIDTH * sheet.SPRITE_HEIGHT]; //the amount of pixels of a particular sprite
	  int current = 0; //Current sprite thats being worked with
	  
	  for(int yp = 0; yp < sheet.getHeight() / sheet.SPRITE_HEIGHT; yp++) { //yp and xp, y position and x position
		  for(int xp = 0; xp < sheet.getWidth() / sheet.SPRITE_WIDTH; xp++) { //amount of sprite horizontally
			  
			  for(int  y = 0; y < sheet.SPRITE_HEIGHT; y++) { //every pixel of the sprite
				  for(int x = 0; x < sheet.SPRITE_WIDTH; x++) {
					  int xo = x + xp * sheet.SPRITE_WIDTH; //x offset
					  int yo = y + yp * sheet.SPRITE_HEIGHT; //y offset
					  pixels[x + y * sheet.SPRITE_WIDTH] = sheet.getPixels() [xo + yo * sheet.getWidth()];
				  }
			  }
			  //current++ start with 0 and then increments, if ++current will increment first and start at 1
			  sprites[current++] = new Sprite(pixels, sheet.SPRITE_WIDTH, sheet.SPRITE_HEIGHT);
		  }
	  }
	  
	  return sprites;
  }
  

  //Methods
  private void setColor(int color) {
    for(int i = 0; i < width * height; i++) {
      pixels[i] = color;
    }
  }

  public int getWidth() {
    return width;
  }

  public int getHeight() {
    return height;
  }

  private void load() {
    for(int y = 0; y < height; y++) {
      for(int x = 0; x < width; x++) {
        pixels[x + y * width] = sheet.pixels[(x + this.x) + (y + this.y) * sheet.SPRITE_WIDTH]; // stores specific sprite
      }
    }
  }

}
