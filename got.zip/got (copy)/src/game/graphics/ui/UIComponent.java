package game.graphics.ui;

import java.awt.Color;
import java.awt.Graphics;

import game.util.Vector2i;

//Particular piece that will be placed on a panel, the panel is then places of the UI

public class UIComponent {
	
	public Vector2i position, size;
	protected Vector2i offSet;
	public Color color; //color of font
	protected UIPanel panel;
	
	public boolean active = true; //tell whether or not something is active

	
	public UIComponent(Vector2i position) {
		this.position = position;
		offSet = new Vector2i();
	}
	
	public UIComponent(Vector2i position, Vector2i size) {
		this.position = position;
		this.size = size;
		offSet = new Vector2i();
	}
	
	void init(UIPanel panel) {
		this.panel = panel;
	}
	
	public UIComponent setColor(int color) {
		this.color = new Color(color);
		return this;
	}
	
	public void update() {
	}
	
	public void render(Graphics g) {	
	}

	public Vector2i getAbsolutePosition() { //return specific location of a component
		return new Vector2i(position).add(offSet);
	}
	
	void setOffSet(Vector2i offSet) { //use default visibility
		this.offSet = offSet;
	}
	
}
