package game.entity.mob;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;

import game.Game; //Imported for getWindowWidth() and getWindowHeight() methods
import game.Game.STATE;
import game.entity.Entity;
import game.entity.projectile.Projectile;
import game.entity.projectile.WizardProjectile;
import game.graphics.AnimatedSprite;
import game.graphics.Screen;
import game.graphics.Sprite;
//import game.graphics.Font;
import game.graphics.SpriteSheet;
import game.graphics.ui.MiniMap;
import game.graphics.ui.UIActionListener;
import game.graphics.ui.UIButton;
import game.graphics.ui.UIButtonListener;
import game.graphics.ui.UILabel;
import game.graphics.ui.UIManager;
import game.graphics.ui.UIPanel;
import game.graphics.ui.UIProgressBar;
import game.input.Keyboard;
import game.input.Mouse;
import game.level.Level;
import game.level.Maps;
import game.level.TileCoordinate;
import game.level.TownLevel;
import game.level.tile.Tile;
import game.util.ImageUtils;
import game.util.Vector2i;



public class Player extends Mob { //Don't need to import class Mob, since Player class is in same folder

	private String name;
	private Keyboard input;
	private Sprite sprite, sprite1; // private sprite variable that gets applied to orientate direction of player sprite
	private Player player;
	private Game game;
	
	private int time;
	private int anim = 0; //animation counter for player sprite walking movement
	private int fireRate = 0; //players 'gun'
	protected int magic; //Sets limit on how long player can fire
	protected static int direction; //Direction player faces 
	
	boolean walking = false; //determines if player is walking
	protected boolean shooting = true;
	private boolean clicked = false;
	
	private static boolean swordAttack = false;
	private boolean isDead = false; //determines whether or not to render dead chicken
	private int deathSpotX, deathSpotY;
	boolean stop = false;
	boolean timer = false; // start count to update dead chicken
	private boolean swimming = false; //If player is swimming cannont attack!
	
	private AnimatedSprite animDeadChicken = new AnimatedSprite(SpriteSheet.chicken_dead, 112, 16, 7);
		
	//No sword
	private AnimatedSprite down = new AnimatedSprite(SpriteSheet.player_down, 32, 32, 3); //For player movements
	private AnimatedSprite up = new AnimatedSprite(SpriteSheet.player_up, 32, 32, 3);
	private AnimatedSprite left = new AnimatedSprite(SpriteSheet.player_left, 32, 32, 3);
	private AnimatedSprite right = new AnimatedSprite(SpriteSheet.player_right, 32, 32, 3);
	
	private AnimatedSprite swimming_down = new AnimatedSprite(SpriteSheet.playerSwimming_down, 32, 32, 3);
	private AnimatedSprite swimming_up = new AnimatedSprite(SpriteSheet.playerSwimming_up, 32, 32, 3);
	private AnimatedSprite swimming_left = new AnimatedSprite(SpriteSheet.playerSwimming_left, 32, 32, 3);
	private AnimatedSprite swimming_right = new AnimatedSprite(SpriteSheet.playerSwimming_right, 32, 32, 3);

	
	//Sword is out, but not attacking
	private AnimatedSprite sword_down = new AnimatedSprite(SpriteSheet.playerSword_down, 32, 32, 3);
	private AnimatedSprite sword_up = new AnimatedSprite(SpriteSheet.playerSword_up, 32, 32, 3);
	private AnimatedSprite sword_left = new AnimatedSprite(SpriteSheet.playerSword_left, 32, 32, 3);
	private AnimatedSprite sword_right = new AnimatedSprite(SpriteSheet.playerSword_right, 32, 32, 3);
	
	//Standing and attacking
	private AnimatedSprite attackStanding_down = new AnimatedSprite(SpriteSheet.playerAttackStanding_down, 32, 32, 3); //Not waling attack sprites 
	private AnimatedSprite attackStanding_up = new AnimatedSprite(SpriteSheet.playerAttackStanding_up, 32, 32, 3); //Not waling attack sprites 
	private AnimatedSprite attackStanding_left = new AnimatedSprite(SpriteSheet.playerAttackStanding_left, 32, 32, 3); //Not waling attack sprites 
	private AnimatedSprite attackStanding_right = new AnimatedSprite(SpriteSheet.playerAttackStanding_right, 32, 32, 3); //Not waling attack sprites 
	
	//Walking and attacking
	private AnimatedSprite attack_down = new AnimatedSprite(SpriteSheet.playerAttack_down, 32, 32, 3);
	private AnimatedSprite attack_up = new AnimatedSprite(SpriteSheet.playerAttack_up, 32, 32, 3);
	private AnimatedSprite attack_left = new AnimatedSprite(SpriteSheet.playerAttack_left, 32, 32, 3);
	private AnimatedSprite attack_right = new AnimatedSprite(SpriteSheet.playerAttack_right, 32, 32, 3);

	private AnimatedSprite animSprite = down; //intial spawn direction is down
	
	//UI
	private UIManager ui; 
	private UIProgressBar uiHealthBar, uiMagicBar;
	private UIButton itemsButton, buttonSwordBackground, buttonMagicBackground;
	
	private BufferedImage imageSword,imageHoverSword, imagePressedSword, imageReleasedSword;
	private BufferedImage imageMagic, imageHoverMagic, imagePressedMagic, imageReleasedMagic; // used for change image color upon hover
	
	
	//CONSTRUCTORS
	public Player(String name, Keyboard input){
		this.name = name;
	    this.input = input; //this sets input of Player() to 'this.input'
	    sprite = Sprite.player;
	    //sprite = Sprite.playerSword;
	}
	
	public Player(int x, int y) {
		this.x = x;
		this.y = y;
	}
	

	public Player(String name, int x, int y, Keyboard input) { //Constructor, Player constructor with X and Y because some times players need to be created in a certain location.
		this.x = x; // since Player class extends Mob, dont need to create new x and y integers, just can us 'this'
		this.y = y;
		this.input = input;
		//sprite = Sprite.player;
		//sprite = Sprite.playerSword;
		fireRate = WizardProjectile.FIRE_RATE;
		
		ui = Game.getUIManager();
		UIPanel panel = (UIPanel) new UIPanel(new Vector2i((300 - 80) * 3, 0), new Vector2i(80 * 3, 168 * 3)).setColor(0x4f4f4f); //300 - 80 sets panel on right side of screen
		ui.addPanel(panel);
		UILabel nameLabel = new UILabel(new Vector2i(10, 250), name);
		nameLabel.setColor(0xbbbbbb);
		nameLabel.setFont(new Font("Helvetica", Font.BOLD, 21));
		panel.addComponent(nameLabel);
		
		
		//Health Bar
		uiHealthBar = new UIProgressBar(new Vector2i(10, 270), new Vector2i(80 * 3 - 20, 30));
		uiHealthBar.setColor(0x9b9b9b); //light grey
		uiHealthBar.setForegroundColor(0xe80d0d); //red
		panel.addComponent(uiHealthBar);
		
		UILabel hpLabel = new UILabel(new Vector2i(uiHealthBar.position).add(new Vector2i(2, 20)), "HP");
		hpLabel.setColor(0xffffff);
		hpLabel.setFont(new Font("Verdana", Font.PLAIN, 20));
		panel.addComponent(hpLabel);
		
		//Magic Bar
		uiMagicBar = new UIProgressBar(new Vector2i(10, 320), new Vector2i(80 * 3 - 20, 30));
		uiMagicBar.setColor(0x9b9b9b);
		uiMagicBar.setForegroundColor(0x00bbff);
		panel.addComponent(uiMagicBar);
		
		UILabel mpLabel = new UILabel(new Vector2i(uiMagicBar.position).add(new Vector2i(2, 20)), "MP"); //MP = magic power
		mpLabel.setColor(0xffffff);
		mpLabel.setFont(new Font("Verdana", Font.PLAIN, 20));
		panel.addComponent(mpLabel);
		
		//UI Buttons
		itemsButton = new UIButton(new Vector2i(140, 440), new Vector2i(90, 50), new UIActionListener() {
			public void perform() {
				//System.exit(0);
				System.out.println("ActionPerformed!!!");
			}
		});
		/*
		 * Overrides buttonListener, keep if want to override default behavior of button
		 */
		/*
		button.setButtonListener(new UIButtonListener() {
			public void pressed(UIButton button) {
				super.pressed(button);
				button.performAction();
				button.ignoreNextPress();
			}
		});
		*/
		 
		itemsButton.setText("Items");
		panel.addComponent(itemsButton);
		
		//SWORD BUTTON 
		try { 
			imageSword = ImageIO.read(getClass().getResource("/game/res/sword_image.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		imageHoverSword = ImageUtils.changeBrightness(imageSword, 255);
		imagePressedSword = ImageUtils.changeBrightness(imageSword, -250);
		imageReleasedSword = ImageUtils.changeBrightness(imageSword, 250);
		
		UIButton imageButtonSword = new UIButton(new Vector2i(0, 370), imageSword, new UIActionListener() {
			public void perform() {
				System.out.println("ActionPerformed!!!");
			}
		});
		
		//MAGIC BUTTON
		try { 
			imageMagic = ImageIO.read(getClass().getResource("/game/res/magic_image.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		imageHoverMagic = ImageUtils.changeBrightness(imageMagic, 250);
		imagePressedMagic = ImageUtils.changeBrightness(imageMagic, -250);
		imageReleasedMagic = ImageUtils.changeBrightness(imageMagic, 250);
			
		UIButton imageButtonMagic = new UIButton(new Vector2i(80, 410), imageMagic, new UIActionListener() {
			public void perform() {
				System.out.println("ActionPerformed!!!");
			}
		});

		//SWORD LISTENER
		imageButtonSword.setButtonListener(new UIButtonListener() {
			public void entered(UIButton button) {
				imageButtonSword.setImage(imageHoverSword);
			}
			public void exited(UIButton button) {
				if(clicked) imageButtonSword.setImage(imageReleasedSword);
				if(!clicked) imageButtonSword.setImage(imageSword);
			}
			public void pressed(UIButton button) {
				imageButtonSword.setImage(imagePressedSword);
				imageButtonMagic.setImage(imageMagic); //resets magic button if sword is pressed, since only one weapon can be chosen at a time
				clicked = true; //Sets boolean for sprite to change
				changeSprite(); //Switches directly to sword wielding player
			}
			public void released(UIButton button) {
				imageButtonSword.setImage(imageSword);
				imageButtonSword.setImage(imageReleasedSword);
			}
			
		});
		panel.addComponent(imageButtonSword);
	
		//MAGIC LISTENER
		imageButtonMagic.setButtonListener(new UIButtonListener() {
			public void entered(UIButton button) {
				imageButtonMagic.setImage(imageHoverMagic);
			}
			public void exited(UIButton button) {
				if(!clicked) imageButtonMagic.setImage(imageReleasedMagic);
				if(clicked) imageButtonMagic.setImage(imageMagic);
			}
			public void pressed(UIButton button) {
				imageButtonMagic.setImage(imagePressedMagic);
				imageButtonSword.setImage(imageSword);
				clicked = false; //sets boolean so player will be set to initial sprite 
				changeSprite();

			}
			public void released(UIButton button) {
				imageButtonMagic.setImage(imageMagic);
				imageButtonMagic.setImage(imageReleasedMagic);
			}
		});
		panel.addComponent(imageButtonMagic);

		
		// Player default attributes
		health = 100;
		magic = 100;
	}
	
	
	/*
	 * Changes player Sprite between standing, standing+sword, standing+attacking, walking+attacking sprite
	 * 0 = down, 1 = up, 2 = left, 3 = right
	 */
	public void changeSprite() {
		
		//Player is on water = swimming
		if(level.getTile((int)x >> 4, (int)y >> 4) == Tile.water) {
			System.out.println("On WATER");
			if(direction == 0) animSprite = swimming_down;
			if(direction == 1) animSprite = swimming_up;
			if(direction == 2) animSprite = swimming_left;
			if(direction == 3) animSprite = swimming_right;

		}
		else {
			if(clicked) {
				if(Mouse.getButton() != 1) { 
					if(direction == 0) animSprite = sword_down;
					if(direction == 1) animSprite = sword_up;
					if(direction == 2) animSprite = sword_left;
					if(direction == 3) animSprite = sword_right;
				} else if(Mouse.getButton() == 1) {
					//Sprite NOT walking
					if(direction == 0 && !walking) animSprite = attackStanding_down;
					if(direction  == 1 && !walking) animSprite = attackStanding_up;
					if(direction == 2 && !walking) animSprite = attackStanding_left;
					if(direction  == 3 && !walking) animSprite = attackStanding_right;
					
					//Sprite is walking
					if(direction == 0 && walking) animSprite = attack_down;
					if(direction == 1 && walking) animSprite = attack_up;
					if(direction == 2 && walking) animSprite = attack_left;
					if(direction == 3 && walking) animSprite = attack_right;
					swordAttack = true; //determines if mob is attacked
				} 
			}
			if(!clicked) { //Sword button is not clicked, player is in normal position, sword is away
				if(direction == 0) animSprite = down;
				if(direction == 1) animSprite = up;
				if(direction == 2) animSprite = left;
				if(direction == 3) animSprite = right;
				swordAttack = false; //resets attack
			}
		}
	}
	
	public String getName() {
		return name;
	}
	
	public void setSwordAttack(boolean b) {
		swordAttack = b;
	}
	public boolean getSwordAttack() {
		return swordAttack;
	}
	public void setDeadLocation(double x, double y) {
		//new DeadChicken(x, y);
	}

	
	public void checkAttack(List<Entity> entities) {
		if(swordAttack) {
			//IMPORTANT: Index starts at 3 because that is where "killable" entities start in ArrayList
			for(int i = 3; i < entities.size(); i++) {
				Entity e = entities.get(i);
				if(
					e.getX() > x - 16 &&
					e.getX() < x + 16 &&
					e.getY() > y - 16 &&
					e.getY() < y + 16) {
					this.deathSpotX = (int)e.getX();
					this.deathSpotY = (int)e.getY();
					this.isDead = true;
					this.timer = true;
					DeadChicken deadChicken = new DeadChicken(deathSpotX * 16, deathSpotY * 16);
					level.add(deadChicken);					
					entities.remove(e);
				}
			}
		}
	} 
	
	/*
	 * switches levels throughout the game
	 */
	/*
	public void changeLevel() {
		if((int)getX() >> 4 == 142 && (int)getY() >> 4 == 72) {
			Game.state = Game.STATE.GAME_PAM_HOUSE;
			this.x = 5 * 16;
			this.y = 7 * 16;
			System.out.println("x = " + getX() + " y = " + getY() );
		}
		if(Game.state == Game.STATE.GAME_PAM_HOUSE && (int)getX() >> 4 == 4 || (int)getX() >> 4 == 5 && (int)getY() >> 4 == 8) {
			Game.state = Game.STATE.GAME;
			this.x = 142 << 4;
			this.y = 73 << 4;
		}
	} */
	

	//METHODS
	public void update() { // need update method, because if key is pressed new the Player to be updated,this overrides update in Mob class
		
		//Checks to see if standing on a level exit tile
		if(level.getTile((int) x >> 4, (int) y >> 4).exit()) {
			//Maps.town.add(new Pam(142, 75));
			//game.getLevel().checkExits(this); //refers to the instance of 'this' class
		}
		
		/*
		 * Controls feathers for chicken death
		 */		
		if(timer)time++;
		if(time < 60 && timer == true) animDeadChicken.update(); //limits feather movement after interval of time
		else {
			this.timer = false; //reset
			time = 0;
		}
		
		//Removes dead entity
		for(int i = 0; i < level.getEntity().size(); i++) {
			checkAttack(level.getEntity());
			swordAttack = false; //Resets sword attack
			//chickenDeath.update(); //Fix this
		}
		if(swimming) changeSprite();
		
		else if(!swimming) {
			if(walking) animSprite.update(); //if player moves then render walking else set the frame to standing
			
			if(!walking && Mouse.getButton() == 1) {
				changeSprite();
				if(clicked) animSprite.update();
			}
			if(!walking && Mouse.getButton() != 1) animSprite.setFrame(0); //resets frame when not moving
		}
		
		if(fireRate > 0) fireRate--;
		double xa = 0, ya = 0; //it resets values after each update
		double speed = 1.4;
		if(anim < 7500) anim++; // arbitrary number 7500, avoids game crash if game is run to long and anim exceed int bounds
		else anim = 0; // resets anim to aviod game crash
		
		if(input.up) {
			//animSprite = up;
			//animSprite = sword_up;
			direction = 1; //set players direction inorder to change to proper sprite for weapon choice
			changeSprite();
			ya -= speed;
		} else if(input.down) {
			//animSprite = down;
			//animSprite = sword_down;
			direction = 0;
			changeSprite();
			ya += speed;
		}
		if(input.left) {
			//animSprite = left;
			//animSprite = sword_left;
			direction = 2;
			changeSprite();
			xa -= speed;
		} else if(input.right) {
			//animSprite = right;
			//animSprite = sword_right;
			direction = 3;
			changeSprite();
			xa += speed;
		}
		
		if(xa != 0 || ya != 0) {
			move(xa, ya);
			walking = true;
		} else {
			walking = false;
		}
		
		clear();
		
		/*
		 * limits shooting and attack to only game screen if clicked. Can attac by clicking
		 * UI. This is improper way of handle event. Change at later date.
		 */
		if(Mouse.getX() < 660)
			//Executes firing update if sword button is NOT pressed
			if(!clicked) updateShooting();
					
		uiHealthBar.setProgress(health / 100.0); //sets initial health meter
		uiMagicBar.setProgress(magic / 100.0); //sets initial magic meter
		
		
		// One technique to move player
		/*
		if(input.up) y--;
		if(input.down) y++;
		if(input.right) x++;
		if(input.left) x--;
		*/
	}
	

	private void clear() { // removes projectiles from Projectile list and is part of player class since players will be using projectiles
		for(int i = 0; i < level.getProjectiles().size(); i++) { //MUST remove extra projectiles from list other wise performance will be effected and game can crash!
			Projectile p = level.getProjectiles().get(i);
			if(p.isRemoved()) level.getProjectiles().remove(i);
		}
	}
	
	/*
	//Updates attack with sword
	private void updateAttack() {
		if(Mouse.getButton() == 1 && clicked == true) {
			//Sprite is NOT walking
			if(direction == 0 && !walking) animSprite = attackStanding_down;
			if(direction == 1 && !walking) animSprite = attackStanding_up;
			if(direction == 2 && !walking) animSprite = attackStanding_left;
			if(direction == 3 && !walking) animSprite = attackStanding_right;
			
			//Sprite is walking
			if(direction == 0 && walking) animSprite = attack_down;
			if(direction == 1 && walking) animSprite = attack_up;
			if(direction == 2 && walking) animSprite = attack_left;
			if(direction == 3 && walking) animSprite = attack_right;

		}
	} */
	
	private void updateShooting() {
		
		if(Mouse.getButton() == 1 && fireRate <= 0) { //only shoot when mouse is clicked AND fireRate is back to 0
			
			if(magic > 0) { // Only fires if magic is NOT empty
				double dx = Mouse.getX() - Game.getWindowWidth() / 2; // double because atan needs double paramters
				double dy = Mouse.getY() - Game.getWindowHeight() / 2; //subtract the screen with because player is always in center of screen
				double dir = Math.atan2(dy, dx); // angle of mouse pointer
				// shoot method is located in mob class because other mobs can shoot as well
				shoot(x, y, dir); //x and y are players position and projectile goes in direction dir
				fireRate = WizardProjectile.FIRE_RATE; // resets fire rate after shooting
			} 
			
			// Diminishes Magic Power bar
			if(magic > 15)
				uiMagicBar.setProgress((magic -= 15 % 100) / 100.0);
			else { 
				uiMagicBar.setProgress(magic = 0); //set to zero since implies player is still shooting
			}
		}
		else if(Mouse.getButton() != 1 && magic < 100) uiMagicBar.setProgress((magic += 1 % 100) / 100.0); //If player stops shooting and power is less than zero replenish.
		//uiHealthBar.setProgress((time++ % 100) / 100.0); //animation 
	}
	
	// Best practice is to set location of the camera rather than setting location of player. Not good to fix player to center of the screen!!
	public void render(Screen screen) { //and of course this will render the game, this overrides render in Mob class
		//THIS CODE IS NOT LONGER BEING USED TO ANIMATE THE SPRITE MOVEMENT OF PLAYER. ANIMATED SPRITE CLASS HANDLES IT AS WELL AS animSprite
		  /*  if(dir == 0 ) {
		  sprite = Sprite.player_downward;
		  if(walking) {
		    if(anim % 20 > 10) { // 60 animations per second so 60 % 20 is is like half the time flip it, every 20 multiples of anim
		      sprite = Sprite.player_downward_1;
		    } else {
		        sprite = Sprite.player_downward_2;
		      }
		  }
		}
		if(dir == 2 ) {
		  sprite = Sprite.player_forward;
		  if(walking) {
		    if(anim % 20 > 10) {
		      sprite = Sprite.player_forward_1;
		    } else {
		        sprite = Sprite.player_forward_2;
		      }
		  }
		}
		if(dir == 3 ) {
		  sprite = Sprite.player_left;
		  if(walking) {
		    if(anim % 20 > 10) {
		      sprite = Sprite.player_left_1;
		    } else {
		        sprite = Sprite.player_left_2;
		      }
		  }
		}
		if(dir == 1 ) {
		  sprite = Sprite.player_right;
		  if(walking) {
		    if(anim % 20 > 10) {
		      sprite = Sprite.player_right_1;
		    } else {
		        sprite = Sprite.player_right_2;
		      }
		  }
		} */
		sprite1 =  animDeadChicken.getSprites();
		screen.renderPlayerDynamic(deathSpotX - 16, deathSpotY, sprite1);
		sprite = animSprite.getSprites();
		screen.renderPlayer((int) (x) - 16, (int) (y) - 16, sprite); // -16 to help center sprite
		
		/*
		// USED FOR RENDERING CHARACTER SPRITE IN 4 PIECES
		int xx = x - 16; // used to help center sprite by offsetting it by 16 pixels
		int yy = y - 16;
		
		screen.renderPlayer(x, y, sprite.player0);
		screen.renderPlayer(x, y + 16, sprite.player1);
		screen.renderPlayer(x + 16, y, sprite.player2);
		screen.renderPlayer(x + 16, y + 16, sprite.player3);
		*/
	}
	
	public void render(Graphics g) {
		
		Player player = level.getClientsPlayer(); //gets the very first player in the players arrayList
		Graphics2D g2 = (Graphics2D) g;
		int x = (int)player.getX() >> 4; //actual pixel width size of world
		int y = (int)player.getY() >> 4;
		double mapScaleX = 0.75; //scales width down to minimap size 225/300
		double mapScaleY = 0.79; // 158/200
		double miniMapPositionX = 670.0; //relocate xposition of point
		double miniMapPositionY = 60.0; //relocates yposition of point
		
		//xPoint & yPointer is coordinates of dot to be placed on minimap
		int xPointer = (int)(miniMapPositionX +  mapScaleX * (double)x) ;
		int yPointer = (int)(miniMapPositionY + mapScaleY * (double)y);
		
		g2.setColor(Color.WHITE);
	
		g2.fillRect(xPointer, yPointer, 4, 4);
	} 
}
