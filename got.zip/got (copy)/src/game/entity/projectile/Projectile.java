package game.entity.projectile;

import game.entity.Entity;
import game.graphics.Sprite;
import java.util.Random;

public abstract class Projectile extends Entity {

  protected final double xOrigin, yOrigin; //This is the spawn point of the projectile
  protected double angle; // angle of the projectile
  protected Sprite sprite; //the sprite for the projectile
  protected double nx, ny; //Vectors of the projectile
  protected double x, y; //overrides x and y values in WizardProjectile inorder to keep precision to double to make render projectile sprite smooth angle
  protected double speed, range, damage;
  protected double distance; // distance projectile has travelled from the origin

  protected final Random random = new Random(); //final because only one instance used. Used for random range of projectile

  public Projectile(double x, double y, double dir) {
    xOrigin = x;
    yOrigin = y;
    angle = dir;
    this.x = x;
    this.y = y;
  }

  public Sprite getSprite() { //gets sprite projectile
    return sprite;
  }

  public int getSpriteSize() {
    return sprite.SIZE;
  }

  protected void move() {

  }
}
