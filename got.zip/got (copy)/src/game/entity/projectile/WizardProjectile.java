package game.entity.projectile;

import game.graphics.Screen;
import game.graphics.Sprite;
import game.entity.spawner.ParticleSpawner;

//Contains all projectiles for wizard 'like' characters

public class WizardProjectile extends Projectile {

  public static final int FIRE_RATE = 15; // *Higher is slower the time between projectiles being fired

  public WizardProjectile(double x, double y, double dir) {
    super(x, y, dir);
    range = random.nextInt(100) + 150; // how far projectile can travel, range is randomly between 150-250
    damage = 30;
    speed = 2; // speed of projectile
   // sprite = Sprite.wizard_projectile;
   // sprite = Sprite.projectile_ax;
    sprite = Sprite.rotate(Sprite.wizard_projectile2, angle); //Directional wizard fire ball

    nx = speed * Math.cos(angle); // vector speed of the projectile. Can't move actuall diagonal so move in x and y direction rapidly to appear like diagonal movement
    ny = speed * Math.sin(angle);
  }
  
  private int time = 0;

  public void update() {
    if(level.tileCollision((int) (x + nx), (int) (y + ny), 11, 0, 0)) { // 11, 0, 0 are the projectile size, xOffset and yOffset respectively. The offsets account for the sprite not being drawin in top left corner of sprite cell
      level.add(new ParticleSpawner((int) x, (int) y, 44, 50, level)); // this specifies level
      remove(); //projectiles collidor, 11 is the size of the projectile, 11 pixels long and high
    }
    // Causes sprite to rotate (spin) DELETE IF NO SPIN IS WANTED
    time++;
    if(time % 6 == 0) { //10 times per second
    	sprite = Sprite.rotate(sprite, Math.PI / 20);
    }
    // end of spin
    move();
  }

  protected void move() {
      x += nx;
      y += ny;
    if(distance() > range) remove();
  }

  private double distance() {
    double dist;
    dist = Math.sqrt((xOrigin - x) * (xOrigin - x) + (yOrigin - y) *(yOrigin - y) ); //Distance formula, just took absolute value to be on safe side, dont think its needed
    return dist;
  }

  public void render(Screen screen) {
   // screen.renderProjectile((int)x - 8, (int)y, this); // -8 adjust the location of the projectile
    screen.renderProjectile((int)x - 8, (int)y, this);
  }
}
