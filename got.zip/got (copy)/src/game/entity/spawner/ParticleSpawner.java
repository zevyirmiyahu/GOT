package game.entity.spawner;

import game.level.Level;
import game.entity.particle.Particle;

public class ParticleSpawner extends Spawner {

  protected int life; //how long particle last

  //Constructor
  public ParticleSpawner(int x, int y, int life, int amount, Level level) {
    super(x, y,Type.PARTICLE, amount, level);
    this.life = life;
    for(int i = 0; i < amount; i++) {
        level.add(new Particle(x, y, life));
    }
  }
}
