package game;

import java.awt.Canvas;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;
import java.net.URL;

import javax.swing.ImageIcon;
//import java.awt.Font; // imports font class, not being used. Instead using custom font
import javax.swing.JFrame;

import game.entity.mob.Player;
import game.graphics.Font;
import game.graphics.Screen; //import custom Screen class to main class
import game.graphics.ui.MiniMap;
import game.graphics.ui.UIManager;
import game.input.Keyboard; //import custom Keyboard class to main class
import game.input.Mouse; //import custom Mouse class to Main class
import game.level.Level;
import game.level.Maps;
import game.level.TileCoordinate;
import game.level.TownLevel;
import game.menus.Menu;
import game.menus.OpeningMenu;

// by extend Canvas Game is like a subclass of Canvas and inherits everthing Canvas has. Canvas is like a blank rectangle we can manipulate(draw on, listen to events,..etc.) implements means class takes designated behavior of that interface.
public class Game extends Canvas implements Runnable {
	private static final long serialVersionUID = 1L;

	// Default visibility, Menu needs these values
	private static int width = 300 - 80; //default visibility for use in Menu
	private static int height = 168; // width / 16 * 9; 16:9 ratio screen
	
	private static int scale = 3; //Scale the window by 3, be retains width pixel amount. i.e. just magnifies
	
	public static String title = "The Gods of Time";
	private boolean running = false; //indicator for program running

	private static UIManager uiManager;
	
	private Thread thread;
	private JFrame frame; //Frame to put Canvas on
	private static Keyboard key; //For input
	public static Game game;
	private Level level; //level object, note only have one level loaded at a time, thus only one level object is needed
	public Level level2; //Inside pams house level
	private Player player; //Make a player object
	private MiniMap miniMap;	
	private Screen screen; // refers to Screen class
	private Font font; //Custom version of font made in the font class
	private BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB); //(*creating the image*) main image object, it's the final rendered view in the game. Not gonna scale, only want amount of pixels defined in widht and height. Have to give BufferedImage a type as well.
	
	private URL imgURL = this.getClass().getResource("/game/res/Cursor.png"); //Used for mouse cursor image
	private Image cursorImage = new ImageIcon(imgURL).getImage();
	
	// Transparent 16 x 16 pixel cursor image.
	BufferedImage cursorImg = new BufferedImage(16, 16, BufferedImage.TYPE_INT_ARGB);

	// Create a new blank cursor.
	Cursor blankCursor = Toolkit.getDefaultToolkit().createCustomCursor(cursorImg, new Point(0, 0), "blank cursor");
	
	private int[] pixels = ((DataBufferInt)image.getRaster().getDataBuffer()).getData(); //(*Accessing the image*) pixels to set the image, image referring to buffered image. This all gives an array of integers representing each pixel of the image
	
	private Menu menu;
	private OpeningMenu opening;
	
	public static enum STATE { //State, Determines if game is at menu or in the game
		MENU, // Main Menu
		OPENING_MENU, // Opening Menu, displays short story
		SELECTION_MENU, // Player chooses character here.
		GAME, // mainLevel		
	};
	
	public static STATE state = STATE.GAME; // State variable allows to check which state game is in
	
	
	//Constructor for game class. **MUST instanstiate all objects within constructor. If instantiate them outside constructor java will instantiate them before the game is even started and the game will crash!
	public Game() {
		Dimension size = new Dimension(width * scale + 80 * 3, height * scale); //create object size for defining screen size
		setPreferredSize(size); // Set size of screen now. setPreferredSize method is in Canvas
		setFocusable(true); // Makes screen active on start to recieve keyboard inputs. Might not need for some computers. Can also put requestFocus();

		//instantiate all objects
		screen = new Screen(width, height); //creates new screen object. Passing width and height into Screen class Constructor and then sets those to the Screen values
		menu = new Menu(); //Initialize Menu Screen
		opening = new OpeningMenu(font); //Initialize OpeningMenu
		uiManager = new UIManager();
		frame = new JFrame();
		key = new Keyboard();
		//level = new RandomLevel(64, 64);
		//level = Level.spawn;
		setLevel(Maps.town); //level changing method called
		TileCoordinate playerSpawn = new TileCoordinate(134, 69);
		player = new Player("Unum The Exalted", playerSpawn.x(), playerSpawn.y(), key); //key is Keyboard class input, numbers are coordinates to spawn player
		level.add(player); //main level
		
		//level2.add(player); //inside pams house
		miniMap = new MiniMap("/game/res/miniMap1.png");
		font = new Font();
		//player.init(level); //Old method for adding player, new technique uses Player List to adding
		
		addKeyListener(key); //key is the Keyboard class input

		Mouse mouse = new Mouse();
		addMouseListener(mouse);
		addMouseMotionListener(mouse);
	}
	
	public Game getGame() {
		return game;
	}
	public Player getPlayer() {
		return player;
	}
	public static Keyboard getKey() {
		return key;
	}
	
	public JFrame getFrame() {
		return frame;
	}
	
	public static int getGameWidth() {
		return width;
	}
	
	public static int getGameHeight() {
		return height;
	}
	
	public static int getGameScale() {
		return scale;
	}

	public static int getWindowWidth() {
		return width * scale;
	}
	public static int getWindowHeight() {
		return height * scale;
	}
	
	public void setLevel(Level level) {
		this.level = level;
	}
	public Level getLevel() {
		return level;
	}
	
	public static UIManager getUIManager() {
		return uiManager;
	}

	public synchronized void start() {
		running = true; // Game has started to set indicator to true
		thread = new Thread(this, "Display"); //This thread, named Display, will contain 'this' game class, same thing as writing: thread = new Thread(new Game() );
		thread.start();
	}

	public synchronized void stop() {
		running = false; // Game stopped, set indicator to false
		try {
			thread.join(); //Joins all threads and waits for them to die, also throws InterruptedException, so need try and catch statements
		} catch(InterruptedException e) {
			e.printStackTrace(); //because that's what everyone always does..
		}
	}

	// game loop
	public void run() {
		long lastTime = System.nanoTime();
		long timer = System.currentTimeMillis();
		final double ns = 1_000_000_000.0 / 60.0; // Final because wont change it, ensures update happens ONLY 60 times per second
		double delta = 0;
		int frames = 0; // Frame counter
		int updates = 0; // should be 60 at all times

		while(running) { //short way of saying: while(running == true)
			long now = System.nanoTime();
			delta += (now - lastTime) / ns; // Controllers how many FPS get rendered by calculated time.
			lastTime = now; // rest lasTime
			while (delta >= 1) {
				update(); //method that handles logic aspect of game, will limit to 60 times per second
				updates++; // count updates
				delta--; // set delta back to continue while loop
			}
			render(); // method that handles graphics/images of game, no limit
			frames++; // counts frames
			if(System.currentTimeMillis() - timer > 1000) {
				timer += 1000;
				System.out.println(updates +"UPS, " + frames + "FPS");
				frame.setTitle(title + " | " + updates +"UPS, " + frames + "FPS"); // printes out UPS and FPS to title
				updates = 0; // Must rest counter
				frames = 0; //Must reset counter
			}
		}
		stop(); // ensures if exit loop then game is stopped properly
	}

	// Don't need x and y varaible for player position, since moved to player class
	//int x = 0, y = 0;

	public void update() { //update method for logic aspect of game
		
		if(state == STATE.GAME) { //If state is game then must update everything
			key.update();
			//player.update(); //using Player List to handle players now, new technic implemented, dont need this
			level.update(); // updates level
			uiManager.update();
		}
		if(state == STATE.MENU) {
			menu.update();
		}
		if(state == STATE.OPENING_MENU) {
			opening.update();
		}
		
			// Below is a bad way of using player movements in game especially if there are multiple players, enemies, etc.
			/*
			if(key.up) y--; //key signals movement/update in image
			if(key.down) y++;
			if(key.left) x--;
			if(key.right) x++;
			*/
	}

	public void render() { //render method for graphics/images of game
		
		BufferStrategy bs = getBufferStrategy(); // Buffer is temperory area to hold data that has already been calculated. This is where frames that are finished being calculated will be held in memory (a buffer), so we use a BufferStrategy.
		//*Note* Canvas comes with its own BufferStrategy, thus we game inherits that because of extends so bs is the BufferStrategy from Canvas
		if (bs == null) { // Only need one BufferStrategy, and render() lies in the game loop, so must limit the creation of bs, otherwise the loop will keep creating a new BufferStrategy everytime...NOT GOOD.
			createBufferStrategy(3); // 'triple BufferStrategy' always set it to 3, need multiple buffering. Allows for speed improvement, computer can render two more images and have them ready to dispay on screen, where as double buffering will have only one image ready, thus display might have to wait for another image to be drawn up in the buffer to dispaly.
			return;
		}
		screen.clear(); // clears screen before new image is rendered
		double xScroll = player.getX() - screen.width / 2; // Gets location of player then subtracts width of screen. Deals with horizontal position of player
		double yScroll = player.getY() - screen.height / 2; // deals with vertical position of player
		
		Graphics g = bs.getDrawGraphics(); // Puts data onto BufferStrategy. getDrawGraphics allows for link between Graphics and Buffer
		g.drawImage(image, 0, 0, width * scale, height * scale, null); //Draws the pixels to screen where width and height are the dimensions of the screen

		if(state == STATE.GAME) {
			//g.drawImage(image, 0, 0, width * scale, height * scale, null); //Draws the pixels to screen where width and height are the dimensions of the screen
			level.render((int) xScroll, (int) yScroll, screen); //center Camera on player
			uiManager.render(g);
			miniMap.render(g); //renders minmap to screen
			player.render(g); //renders players location to miniMap
			//font.render(50, 50, -8, "This is Nox Castle and it\nis the final strong hold. \nTime to start.", screen);
		}
		if(state == STATE.MENU) { // adds 80 to width to fill UI void
			//g.drawImage(image, 0, 0, (width + 80) * scale, height * scale, null); //Draws the pixels to screen where width and height are the dimensions of the screen
			menu.render(g);
		}
		if(state == STATE.OPENING_MENU) {
			g.drawImage(image, 0, 0, (width + 80) * scale, height * scale, null); //Draws the pixels to screen where width and height are the dimensions of the screen
			opening.render(g);
		}
		//font.render(50, 50, -8, "This is Nox Castle and it\nis the final strong hold. \nTime to start.", screen);
		//player.render(screen); // Don't need to do since using PlayerList now, different technic used
		//screen.renderSheet(10, 20, SpriteSheet.player, false); //Renders the whole character spritesheet to the screen
		//screen.render(x, y); // render method will be done from each class, to render contents. calls render() from class Screen to render pixels
		for(int i = 0; i < pixels.length; i++) {
			pixels[i] = screen.pixels[i];
		}	
		
				// Graphics MUST follow chronological order
		//////// Graphics g = bs.getDrawGraphics(); // Puts data onto BufferStrategy. getDrawGraphics allows for link between Graphics and Buffer
		// ***All graphical 'things' must be done in this area before g.dispose();
		// *note setColor() AND fillRect are NOT needed since pixels are being drawn to screen. Can delete two methods.
		//g.setColor(Color.BLACK); // Sets color, must be defined BEFORE filRect. Fill needs to know what color to set.
		//g.fillRect(0, 0, getWidth(), getHeight() ); // getWidth and getHeight are methods of Canvas class, they return an integer. fillRect is filling screen determined by this size
		/////// g.drawImage(image, 0, 0, width * scale, height * scale, null); //Draws the pixels to screen where width and height are the dimensions of the screen
		//uiManager.render(g);
		//g.setColor(Color.WHITE); //Not being used at moment
		//g.setFont(new java.awt.Font("Verdana", 0, 50)); // Not being used at moment
		//g.drawString("hello", 50, 50);
		//g.fillRect(Mouse.getX() - 32, Mouse.getY() - 32, 64, 64); //Makes a mouse pointer
		//g.drawImage(cursorImage, Mouse.getX(), Mouse.getY(), null);
		
		g.drawImage(cursorImage, Mouse.getX() - 32, Mouse.getY() - 32, 64, 64, null);
		//g.fillOval(Mouse.getX(), Mouse.getY(), 16, 16);
		//if(Mouse.getButton() != -1) g.drawString("Button: " + Mouse.getButton(), 80, 80); //writes if mouse button was clicked to the screen
		
		g.dispose(); //Disposes of current Graphics, since render is in loop need to dispose every time, otherwise game will crash
		bs.show(); //makes next available buffer visible
	}

	// Main method
	public static void main(String args[]) {
		//System.setProperty("sun.java2d.opengl", "true"); // ?? Not sure, but stops Ubuntu from freezing up... might have to use, but creates problem rendering pixels in correct way		
		
		Game game = new Game(); // game object
		game.frame.setResizable(false); // Screen can't be adjusted, advoids graphical errors *VERY IMPORTANT
		game.frame.setTitle(title);
		game.frame.add(game); // adds a component ('game') to the frame/ fills it with 'something'
		game.frame.pack(); // Sets size of frame to the component size:  setPreferredSize(size)
		game.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Allows user to exit frame
		game.frame.setLocationRelativeTo(null); // Set default location of frame to center of screen
		game.frame.setVisible(true); // IMPORTANT allows user to see frame
		
		// Set the blank cursor to the JFrame.
		game.frame.getContentPane().setCursor(game.blankCursor); //sets mouse to transparent
		
		game.start(); // Starts the game
		
	}

}
