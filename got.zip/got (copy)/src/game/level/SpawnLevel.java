package game.level;

import java.awt.image.BufferedImage; //BufferedImage class
import javax.imageio.ImageIO; //ImageIO class
import java.io.IOException; //import IOException class

import game.entity.mob.Dummy;
import game.entity.mob.Goon;
import game.entity.mob.MobShooter;
import game.entity.mob.Mummy;
import game.entity.mob.Pam;
import game.entity.mob.Shooter;
import game.entity.mob.Star;
import game.entity.mob.Chaser;

public class SpawnLevel extends Level {

  public SpawnLevel(String path) { // Constructor, load the level directory
    super(path);
  }

  protected void loadLevel(String path) { //method to load level
    try {
      BufferedImage image = ImageIO.read(SpawnLevel.class.getResource(path));
      int w = width = image.getWidth();
      int h = height = image.getHeight();
      tiles = new int[w * h];
      image.getRGB(0, 0, w, h, tiles, 0, w);
    } catch(IOException e) {
    	e.printStackTrace();
    	System.out.println("ATTENTION! Could NOT load level file.");
    }
   
    // ADD MOBS/NPC TO LEVEL
    //for(int i = 0; i < 5; i++) {
    	//add(new MobShooter(25, 35));
    //}
    add(new Mummy(25, 35));
    add(new Goon(26, 30));
    add(new Pam(27, 20));
    //add(new MobShooter(20, 40));
    //add(new Shooter(20, 40));
    //add(new Chaser(20, 40));
    //add(new Star(15, 25)); //LOCATIONS ARE GIVEN IN TILE PRECISION
    //for(int i = 0; i < 5; i++) {
    //	add(new Dummy(25, 45)); //Adds dummy NPC to the level
    //}
  }

  // grass = 0x99e550 (green)
  // grass2 = 0x006600 (darkgreen)
  // flower = 0xfbf236 (yellow)
  //rock = 0x696a6a (grey)
  // water = 0x0000fe (blue)
  protected void generateLevel() {
    /* Not needed because new way of spawning level is used
    for(int i = 0; i < levelPixels.length; i++) {
      if(levelPixels[i] == 0xff99e550) tiles[i] = Tile.grass; // rember to put ff in front of each color because that's how java handles alpha channel, so must write 0xff_______ then the hexidecimal number for the color
      if(levelPixels[i] == 0xff006600) tiles[i] = Tile.grass2;
      if(levelPixels[i] == 0xfffbf236) tiles[i] = Tile.flower;
      if(levelPixels[i] == 0xff696a6a) tiles[i] = Tile.rock;
      if(levelPixels[i] == 0xff0000fe) tiles[i] = Tile.water;
    }
    */
  }

}
