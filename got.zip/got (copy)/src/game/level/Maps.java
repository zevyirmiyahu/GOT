package game.level;

public abstract class Maps {
	
	 // GAME LEVELS/AREAS
	  public static Level spawn = new SpawnLevel("/game/res/spawn_castle.png"); // Castle level map
	  public static Level town = new TownLevel("/game/res/mainLevel.png"); // This is the main area of game
	  public static Level pamHouse = new PamHouseLevel("/game/res/pamsHouse.png"); //Inside house level

}
