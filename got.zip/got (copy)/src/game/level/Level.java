package game.level;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import game.entity.Entity;
import game.entity.mob.DeadChicken;
import game.entity.mob.Player;
import game.entity.particle.Particle;
import game.entity.projectile.Projectile;
import game.graphics.Screen; //Import Screen class
import game.level.tile.AnimatedTile;
import game.level.tile.Tile; //Import Tile class
import game.util.Vector2i;

/* This class generates a level, tiles the level.
*/

public class Level {
  private Player player;
  protected int width, height;
  protected int[] tilesInt;
  protected int[] tiles; // store entire level as pixel array from pixel map
  
  private List<Entity> entities = new ArrayList<Entity> (); // keeps all entities in the game and an Arraylist allows size to be dynamic.
  private List<Projectile> projectiles = new ArrayList<Projectile> (); // bad programming practice since projectile list already exist in Mob class, but quick fix to make projectiles NOT entities
  private List<Particle> particles = new ArrayList<Particle> ();
  
  private List<Player> players = new ArrayList<Player> (); // Contains all player entites (multi player game)

  private static List<AnimatedTile> tiles_anim = new ArrayList<AnimatedTile> (); //Contains list of all animated tiles
  
  private Comparator<Node> nodeSorter = new Comparator<Node>() { //Compares paths for A* Algorithm
	public int compare(Node n0, Node n1) {
		if(n1.fCost < n0.fCost) return +1; //n1 Node is smaller cost, move up in index of array
		if(n1.fCost > n0.fCost) return -1;
		return 0; //if equals return zero
	}
  };
  
  /*
  // GAME LEVELS/AREAS
  public static Level spawn = new SpawnLevel("/game/res/spawn_castle.png"); // Castle level map
  public static Level town = new TownLevel("/game/res/mainLevel.png"); // This is the main area of game
  public static Level pamHouse = new PamHouseLevel("/game/res/pamsHouse.png"); //Inside house level
  */
  // Constructors
  // *NOT using this constructor*
  public Level(int width, int height) { //Constructor, specifies the size of the level to be generated. *this will be default Constructor for RandomLevel because is determines size of the level
    this.width = width;
    this.height = height;
    tilesInt = new int[width * height]; //allocates tilesInt array
    generateLevel(); // The method to create(generate) random level called here
  }
  // *USING this constructor*
  public Level(String path) { // Constructor, load the level directory, for premade level NOT a random level
    loadLevel(path);
    generateLevel(); 
  }

  // Methods

  protected void generateLevel()  { // method defined to generate the random level
  }

  protected void loadLevel(String path) { //method to load level
  }
  

  public void update() { //Method to update the level, used for entities that move through the level, happens at 60FPS(UPS)
	  for(int i = 0; i < tiles_anim.size(); i++) { //Updates animated tiles (water)
		  tiles_anim.get(i).update();
	  }
    for(int i = 0; i < entities.size(); i++) {
      entities.get(i).update(); //updates entites
    }
    for(int i = 0; i < projectiles.size(); i++) {
      projectiles.get(i).update(); //updates projectiles
    }
    for(int i = 0; i < particles.size(); i++) {
      particles.get(i).update(); //updates particles
    }
    for(int i = 0; i < players.size(); i++) {
      players.get(i).update(); //updates players
    }
    remove();
  }

  private void remove() {
    for(int i = 0; i < entities.size(); i++) {
      if(entities.get(i).isRemoved()) entities.remove(i); //updates entites
    }
    for(int i = 0; i < projectiles.size(); i++) {
      if(projectiles.get(i).isRemoved()) projectiles.remove(i); //updates projectiles
    }
    for(int i = 0; i < particles.size(); i++) {
      if(particles.get(i).isRemoved()) particles.remove(i); //updates particles
    }
    for(int i = 0; i < players.size(); i++) {
      if(players.get(i).isRemoved()) players.remove(i); //updates players
    }
  }
    
  public List<Projectile> getProjectiles() { //getter method for projectiles since projectiles are private
    return projectiles;
  }

  private void time() { // for time in game, possibly for day and night settings of game
  }

  // Used for pixel 'perfect' collision // xOffset and yOffset used to align sprite with pixel collision if sprite is NOT drawn to the top left corner in sprite cell
  public boolean tileCollision(int x, int y, int size, int xOffset, int yOffset) { //  size is size of oject, x and y position of enetity (projectile) and xa and ya is the direction it is heading, determines if mob can pass from object in game or not
    boolean solid = false;
    for(int c = 0; c < 4; c++) { // c represents a corner of the tile thus allowing for a slightly more complex collidor system, and if any of those corners of the tile belongs to a solid tile then it sets solid = true
      int xt = (x - c % 2 * size + xOffset) >> 4; // changes collision parameters
      int yt = (y - c / 2 * size + yOffset) >> 4;
      if(getTile(xt, yt).solid()) solid = true;  // divided x+xa and y+ya by 16 to convert to tile precision from pixel percision x is current location, y is current location. xa is position player will move, ya is location player will move
    }
    return solid;
  }
  
  public boolean swimming(double x, double y, int size) { //Tests to see if player is swimming
	  boolean swimming = false;
	  
	  int xOffset = 8;
	  int yOffset = 8;
	  for(int c = 0; c < 4; c++) { // c represents a corner of the tile thus allowing for a slightly more complex collidor system, and if any of those corners of the tile belongs to a solid tile then it sets solid = true
		  int xt = ((int)x - c % 2 * size + xOffset) >> 4; // changes collision parameters
	  	  int yt = ((int)y - c / 2 * size + yOffset) >> 4;
    	  if(getTile(xt, yt).inWater()) swimming = true;  // divided x+xa and y+ya by 16 to convert to tile precision from pixel percision x is current location, y is current location. xa is position player will move, ya is location player will move
	  }
	return swimming;
  }
  

  /* IMPLEMENTED DIFFERENT COLLISION PHYSICS ABOVE
  // Used for projectile collision
  public boolean tileCollision(double x, double y, double xa, double ya, int size) { //  size is size of oject, x and y position of enetity (projectile) and xa and ya is the direction it is heading, determines if mob can pass from object in game or not
    boolean solid = false;
    for(int c = 0; c < 4; c++) { // c represents a corner of the tile thus allowing for a slightly more complex collidor system, and if any of those corners of the tile belongs to a solid tile then it sets solid = true
      int xt = (((int) x + (int) xa) + c % 2 * size / 10 - 4) / 16; // changes collision parameters
      int yt = (((int) y + (int) ya) + c / 2 * size / 10 + 4) / 16;
      if(getTile(xt, yt).solid()) solid = true;  // divided x+xa and y+ya by 16 to convert to tile precision from pixel percision x is current location, y is current location. xa is position player will move, ya is location player will move
    }
    return solid;
  } */
  
  //Method to add animatedTiles to ArrayList
  public static void addTile(AnimatedTile t) {
	  tiles_anim.add(t);
  }

  public void add(Entity e) { // figures out which type of entity and adds to proper ArrayList
    e.init(this);
    if(e instanceof Particle) {
        particles.add((Particle) e); // e is an istance of Particle then we add it to the particles list
    } else if(e instanceof Projectile) {
        projectiles.add((Projectile) e); // add e to Projectile List must cast e into a Projectile but safe to do since if checks it
    } else if(e instanceof Player) { //otherwise its not a particle so we add it to enetitiesList
      players.add((Player) e); // MUST cast as player entity
    } else {
        entities.add(e); //adds entities the the entitiesList
      }
  }

  public List<Player> getPlayers() { //returns instance of player from players List
    return players;
  }
  
  public Player getPlayerAt(int index) {
    return players.get(index);
  }
  
  public Player getClientsPlayer() {
    return players.get(0); //returns the first player, the main player is always first in Player List
  }
  
  public List<Entity> getEntity() {
	  return entities;
  }


/* //this approach doesn't incorporate the use of ArrayList, thus it's not as effective/superior
  public Player getPlayer() {
    for(int i = 0; i < entities.size(); i++) {
      if(entities.get(i) instanceof Player) { //just enetitiesList to see if element is a Player instance
        return (Player) entities.get(i);
      }
    }
    return null; //otherwise just return null
  }
  */

  public void render(int xScroll, int yScroll, Screen screen) { //xscroll = position where map is scrolled to, screen class is whats drawn on screen
    screen.setOffset(xScroll, yScroll);
    // Corner pins of the screen determine which tiles need to get rendered onto the screen/in other words they define render region of the screen
    int x0 = xScroll >> 4; // dividing by 16, but using bitwise operator because it's faster
    int x1 = (xScroll + screen.width + 16) >> 4; // x0 and x1 are vertical lines, like asymmptotes, plus 16 to render tile smoothly to the screen
    int y0 = yScroll >> 4; //  y0 and y1 are like horizontal asymmptotes
    int y1 = (yScroll + screen.height + 16) >> 4; //plus 16  to render tile smoothly to screen
    for(int y = y0; y < y1; y++) {
      for(int x = x0; x < x1; x++) {
        getTile(x, y).render(x, y, screen); // calls getTile method, so tile is retrieved then rendered to screen


        /* //Another way to get tiles, but much more messy way
        if( x + y * 16 < 0 || x + y * 16 >= 256) { // 16 * 16 = 256 the size of the premade level
          Tile.voidTile.render(x, y, screen);
          continue; // skips remainder of code below if statement
        }
        tiles[x + y * 16].render(x, y, screen);
        */

      }
    }
    for(int i = 0; i < entities.size(); i++) {
      entities.get(i).render(screen); //renders entites to the screen
    }
    for(int i = 0; i < projectiles.size(); i++) {
      projectiles.get(i).render(screen); //renders projectiles to the screen
    }
    for(int i = 0; i < particles.size(); i++) {
      particles.get(i).render(screen); // renders particles to the screen
    }
    for(int i = 0; i < players.size(); i++) {
      players.get(i).render(screen);
    }
  }
  
  // A* Algorithm
  public List<Node> findPath(Vector2i start, Vector2i goal) {
	  List<Node> openList = new ArrayList<Node>(); //All possible Nodes(tiles) that could be shortest path
	  List<Node> closedList = new ArrayList<Node>(); //All no longer considered Nodes(tiles)
	  Node current = new Node(start,null, 0, getDistance(start, goal)); //Current Node that is being considered(first tile)
	  openList.add(current);
	  while(openList.size() > 0) {
		  Collections.sort(openList, nodeSorter); // will sort open list based on what's specified in the comparator
		  current = openList.get(0); // sets current Node to first possible element in openList
		  if(current.tile.equals(goal)) {
			  List<Node> path = new ArrayList<Node>(); //adds the nodes that make the path 
			  while(current.parent != null) { //retraces steps from finish back to start
				  path.add(current); // add current node to list
				  current = current.parent; //sets current node to previous node to strace path back to start
			  }
			  openList.clear(); //erases from memory since algorithm is finished, ensures performance is not affected since garbage collection may not be called
			  closedList.clear();
			  return path; //returns the desired result shortest/quickest path
		  }
		  openList.remove(current); //if current Node is not part of path to goal remove
		  closedList.add(current); //and puts it in closedList, because it's not used
		  for(int i = 0; i < 9; i++ ) { //8-adjacent tile possibilities
			  if(i == 4) continue; //index 4 is the middle tile (tile player currently stands on), no reason to check it
			  int x = (int)current.tile.getX();
			  int y = (int)current.tile.getY();
			  int xi = (i % 3) - 1; //will be either -1, 0 or 1
			  int yi = (i / 3) - 1; // sets up a coordinate position for Nodes (tiles)
			  Tile at = getTile(x + xi, y + yi); // at tile be all surrounding tiles when iteration is run
			  if(at == null) continue; //if empty tile skip it
			  if(at.solid()) continue; //if solid cant pass through so skip/ don't consider this tile
			  Vector2i a = new Vector2i(x + xi, y + yi); //Same thing as node(tile), but changed to a vector
			  double gCost = current.gCost + (getDistance(current.tile, a) == 1 ? 1 : 0.95); //*calculates only adjacent nodes* current tile (initial start is 0) plus distance between current tile to tile being considered (a)
			  double hCost = getDistance(a, goal);								// conditional piece above for gCost makes a more realist chasing, because without it mob will NOT use diagonals because higher gCost
			  Node node = new Node(a, current, gCost, hCost);
			  if(vecInList(closedList, a) && gCost >= node.gCost) continue; //is node has already been checked 
			  if(!vecInList(openList, a) || gCost < node.gCost) openList.add(node);
		  }
	  }
	  closedList.clear(); //clear the list, openList will have already been clear if no path was found
	  return null; //a default return if no possible path was found
  }
  
  private boolean vecInList(List<Node> list, Vector2i vector) {
	for(Node n : list) {
		if(n.tile.equals(vector)) return true;
	}
	return false; // if gone through entire list and NOT there return false
  }
  
  // Distance Method used in A* Algorithm above
  private double getDistance(Vector2i tile, Vector2i goal) {
	  double dx = tile.getX() - goal.getX();
	  double dy = tile.getY() - goal.getY();
	  return Math.sqrt(dx * dx + dy *dy); //distance 
  }
  
  // THIS IS GENERAL METHOD FOR ALL ENTITIES
  public List<Entity> getEntities(Entity e, int radius) { //returns an array list of entitie for use of Chaser
    List<Entity> result = new ArrayList<Entity>();
    int ex = (int) e.getX(); //location of player's entity
    int ey = (int) e.getY();
    for(int i = 0; i < entities.size(); i++) {
      Entity entity = entities.get(i); //Current entity
      if(entity.equals(e)) continue; //Don't add itself to the result list
      int x = (int) entity.getX(); //return x position of "foreign" entity
      int y = (int) entity.getY(); //return y position of "foreign" entity

      double dx = Math.abs(ex - x);
      double dy = Math.abs(ey - y);
      double distance = Math.sqrt( (dx * dx) + (dy * dy) ); //the distance between player and entity
      if(distance <= radius) result.add(entity); //then the entity is add to array list
    }
    return result; // return list when finished
  }
  
  //THIS IS SPECIAL METHOD FOR ONLY PLAYERS
  public List<Player> getPlayers(Entity e, int radius) {
    int ex = (int) e.getX(); //location of player's entity
    int ey = (int) e.getY();
    List<Player> result = new ArrayList<Player>();
    for(int i = 0; i < players.size(); i++) {
      Player player = players.get(i);
      int x = (int) player.getX(); //return x position of "foreign" entity
      int y = (int) player.getY(); //return y position of "foreign" entity
      int dx = Math.abs(ex - x);
      int dy = Math.abs(ey - y);
      double distance = Math.sqrt( (dx * dx) + (dy * dy) ); //the distance between player and entity
      if(distance <= radius) result.add(player); //then the entity is add to array list
    }
    return result;
  }
  
  /*
   *  Checks whether level has been exited. Method left blank to be overriden by subclass
   */
  public void checkExits(Player player) {	
  }

  //getTile returns a tile and the above method renders it.
  public Tile getTile(int x, int y) { // getTile method retrieves which tile of the randomly generated ones in RandomeLevel to get, its parameters are simply x and y (the position of the tile)
    if( x < 0 || y < 0 || x >= width || y >= height) return Tile.voidTile; //this must be before evualuating if statement of tiles to avoid crash. Fixes array index out of bounds on the map to avoid crashing when player goes left too far or up too far OR right or down too far. Crashes because either index becomes negative OR we exceed the index
    
    if(tiles[x + y * width] == Tile.col_spawn_grass1) return Tile.spawn_grass1; // 0x tells java its hexidecimal and ff tells it also has alpha channel
    if(tiles[x + y * width] == Tile.col_spawn_grass2) return Tile.spawn_grass2;
    if(tiles[x + y * width] == Tile.col_spawn_grass3) return Tile.spawn_grass3;
    if(tiles[x + y * width] == Tile.col_spawn_grass4) return Tile.spawn_grass4;
    if(tiles[x + y * width] == Tile.col_spawn_chicken_grass) return Tile.spawn_chickenGrass;
    if(tiles[x + y * width] == Tile.col_spawn_grassCollidor) return Tile.spawn_grassCollidor;
    
    if(tiles[x + y * width] == Tile.col_spawn_rock) return Tile.spawn_rock;
    
    if(tiles[x + y * width] == Tile.col_spawn_flower) return Tile.spawn_flower;
    if(tiles[x + y * width] == Tile.col_spawn_flower_pink) return Tile.spawn_flower_pink;
    
    if(tiles[x + y * width] == Tile.col_spawn_sand) return Tile.spawn_sand;
    
    //if(tiles[x + y * width] == Tile.col_spawn_water1) return Tile.spawn_water1;
   if(tiles[x + y * width] == Tile.col_animWater) return Tile.water;

    
    //if(tiles[x + y * width] == Tile.col_spawn_water2) return Tile.spawn_water2;
    //if(tiles[x + y * width] == Tile.col_spawn_water_river) return Tile.spawn_water_river;
    
    if(tiles[x + y * width] == Tile.col_spawn_water_corner_TL) return Tile.spawn_water_corner_TL;
    if(tiles[x + y * width] == Tile.col_spawn_water_corner_TR) return Tile.spawn_water_corner_TR;
    if(tiles[x + y * width] == Tile.col_spawn_water_corner_BR) return Tile.spawn_water_corner_BR;
    if(tiles[x + y * width] == Tile.col_spawn_water_corner_BL) return Tile.spawn_water_corner_BL;
    
    if(tiles[x + y * width] == Tile.col_spawn_water_side_l) return Tile.spawn_water_side_l;
    if(tiles[x + y * width] == Tile.col_spawn_water_side_r) return Tile.spawn_water_side_r;
    if(tiles[x + y * width] == Tile.col_spawn_water_side_t) return Tile.spawn_water_side_t;
    if(tiles[x + y * width] == Tile.col_spawn_water_side_b) return Tile.spawn_water_side_b;
    
    if(tiles[x + y * width] == Tile.col_spawn_water_edge_tl) return Tile.spawn_water_edge_tl;
    if(tiles[x + y * width] == Tile.col_spawn_water_edge_tr) return Tile.spawn_water_edge_tr;
    if(tiles[x + y * width] == Tile.col_spawn_water_edge_bl) return Tile.spawn_water_edge_bl;
    if(tiles[x + y * width] == Tile.col_spawn_water_edge_br) return Tile.spawn_water_edge_br;    
    
    if(tiles[x + y * width] == Tile.col_spawn_cliff) return Tile.spawn_cliff;
    if(tiles[x + y * width] == Tile.col_spawn_cliff_t) return Tile.spawn_cliff_t;
    if(tiles[x + y * width] == Tile.col_spawn_cliff_b) return Tile.spawn_cliff_b;
    if(tiles[x + y * width] == Tile.col_spawn_cliff_l) return Tile.spawn_cliff_l;
    if(tiles[x + y * width] == Tile.col_spawn_cliff_r) return Tile.spawn_cliff_r;
    
    if(tiles[x + y * width] == Tile.col_spawn_cliff_corner_tl) return Tile.spawn_cliff_corner_tl;
    if(tiles[x + y * width] == Tile.col_spawn_cliff_corner_tr) return Tile.spawn_cliff_corner_tr;
    if(tiles[x + y * width] == Tile.col_spawn_cliff_corner_bl) return Tile.spawn_cliff_corner_bl;
    if(tiles[x + y * width] == Tile.col_spawn_cliff_corner_br) return Tile.spawn_cliff_corner_br;
    
    if(tiles[x + y * width] == Tile.col_spawn_cliff_edge_tl) return Tile.spawn_cliff_edge_tl;
    if(tiles[x + y * width] == Tile.col_spawn_cliff_edge_tr) return Tile.spawn_cliff_edge_tr;
    if(tiles[x + y * width] == Tile.col_spawn_cliff_edge_bl) return Tile.spawn_cliff_edge_bl;
    if(tiles[x + y * width] == Tile.col_spawn_cliff_edge_br) return Tile.spawn_cliff_edge_br;
    
    if(tiles[x + y * width] == Tile.col_spawn_brick1) return Tile.spawn_brick1;
    if(tiles[x + y * width] == Tile.col_spawn_brick2) return Tile.spawn_brick2;
    if(tiles[x + y * width] == Tile.col_spawn_brick3) return Tile.spawn_brick3;
    
    if(tiles[x + y * width] == Tile.col_spawn_crack1) return Tile.spawn_crack1;
    if(tiles[x + y * width] == Tile.col_spawn_crack2) return Tile.spawn_crack2;
    
    if(tiles[x + y * width] == Tile.col_spawn_door) return Tile.spawn_door;
    if(tiles[x + y * width] == Tile.col_spawn_wall) return Tile.spawn_wall;
    if(tiles[x + y * width] == Tile.col_spawn_wood_floor) return Tile.spawn_wood_floor;
    
    if(tiles[x + y * width] == Tile.col_mainZone) return Tile.zoneTileDoor;
    if(tiles[x + y * width] == Tile.col_pamZone) return Tile.zoneTile;


    return Tile.voidTile; //returns black tile if edge of map is reached. cant generate an actual void so puts a black tile there
  }	
}
