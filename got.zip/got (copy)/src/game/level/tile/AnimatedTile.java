package game.level.tile;

import game.graphics.AnimatedSprite;
import game.graphics.Screen;
import game.graphics.Sprite;
import game.level.Level;

public class AnimatedTile extends Tile {
	
	private long timer;
	private long now;
	private Sprite sprite;
	private AnimatedSprite animSprite;
	
	
	public AnimatedTile(AnimatedSprite animatedSprite) {
		super(animatedSprite);
		animSprite = animatedSprite;
		Level.addTile(this);
		
	}
	
	public void update() {
		//Limits animation updates
		now = System.currentTimeMillis();
		timer += now % 1000;
		if(timer  >= 1000) {
			animSprite.update();
			timer = 0; //MUST reset Timer to safe guard against crashes
		}
	}
	
	public void render(int x, int y, Screen screen) {
		sprite = animSprite.getSprites();
		Tile tile = new Tile(sprite);
		screen.renderTile( x<< 4, y << 4, tile);
	}

}
