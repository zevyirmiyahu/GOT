package game.level.tile;

import game.graphics.Sprite;
import game.graphics.Screen;

// Tiles for grass

public class GrassTile2 extends Tile {

  public GrassTile2(Sprite sprite) { //Default construtor
    super(sprite);
  }

  public void render(int x, int y, Screen screen) { //Render method for grasstile
    screen.renderTile(x << 4, y << 4, this); //have to convert back to tile precise so mulitply by 16 (use bit wise operator)'this' because we are rendering grassTile and we are in the grassTile class
  }

  // By defualt frome Tile class, grass collidor is false

}
