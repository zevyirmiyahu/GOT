package game.level.tile.spawn_level;

import game.graphics.Screen;
import game.graphics.Sprite;
import game.level.tile.Tile;

public class SpawnCollidorTile extends Tile{
	
	  public SpawnCollidorTile(Sprite sprite) {
		  super(sprite);
	  }
	  
	  // Stops chicken, so chickens are contained to an area
	  public static boolean solid(Sprite sprite) {
		  if(sprite == Sprite.chicken) {
			  return true;
		  } else return false;
	  }
	  
	  public void render(int x, int y, Screen screen) {
		    screen.renderTile( x<< 4, y << 4, this);
		  }
}
