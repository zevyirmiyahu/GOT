package game.level.tile;

import game.graphics.AnimatedSprite;
import game.graphics.SpriteSheet;


public class WaterTile extends AnimatedTile {
	
	private static final AnimatedSprite water = new AnimatedSprite(SpriteSheet.animWater, 16, 16, 3);
	
	public WaterTile() { //Default construtor
		super(water);
	}
	
	public boolean inWater() {
		return true;
	}
}
