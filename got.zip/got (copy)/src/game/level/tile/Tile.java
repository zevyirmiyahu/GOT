package game.level.tile;

import game.graphics.Screen; //import Screen class
import game.graphics.Sprite; //import Sprite class
import game.level.tile.spawn_level.SpawnBrickTile1;
import game.level.tile.spawn_level.SpawnCollidorTile;
import game.level.tile.spawn_level.SpawnCrackTile1;
import game.level.tile.spawn_level.SpawnDoorTile;
import game.level.tile.spawn_level.SpawnFlowerTile;
import game.level.tile.spawn_level.SpawnGrassTile1; //Import each spawn class since in sub directory
import game.level.tile.spawn_level.SpawnRockTile;
import game.level.tile.spawn_level.SpawnWallTile;
import game.level.tile.spawn_level.SpawnWaterTile1;


/* General tile class
ALL tiles NEED:
-sprite
-doesn't have x and y. rendered to screen. position then can be checked
-to be rendered
-collidor (way to determine if its solid OR not)
*/

public class Tile {

  public Sprite sprite;

/*public static Tile grass = new GrassTile(Sprite.grass); //make grass object of Tile and static because only making one grass object and can set Tile = to GrassTile because GrassTile extends Tile class. Thus, we can define the 'rules' for grass in the GrassTile subclass
  public static Tile grass2 = new GrassTile(Sprite.grass2);
  public static Tile flower = new FlowerTile(Sprite.flower);
  public static Tile rock = new RockTile(Sprite.rock);
  public static Tile water = new WaterTile(Sprite.water); */

  public static Tile spawn_grass1 = new SpawnGrassTile1(Sprite.spawn_grass1); // tile instantiate
  public static Tile spawn_grass2 = new SpawnGrassTile1(Sprite.spawn_grass2);
  public static Tile spawn_grass3 = new SpawnGrassTile1(Sprite.spawn_grass3);
  public static Tile spawn_grass4 = new SpawnGrassTile1(Sprite.spawn_grass4);
  public static Tile spawn_chickenGrass = new SpawnGrassTile1(Sprite.spawn_chickenGrass); //used for chicken area
  public static Tile spawn_grassCollidor = new SpawnCollidorTile(Sprite.spawn_grassCollidor); // set boundry for chicken wandering
  
  public static Tile spawn_rock = new SpawnRockTile(Sprite.spawn_rock);
  
  public static Tile spawn_flower = new SpawnFlowerTile(Sprite.spawn_flower);
  public static Tile spawn_flower_pink = new SpawnFlowerTile(Sprite.spawn_flower_pink);
  
  public static Tile spawn_sand = new SpawnGrassTile1(Sprite.spawn_sand);
  
  public static Tile spawn_water1 = new SpawnWaterTile1(Sprite.spawn_water1);
  
  public static Tile water = new WaterTile(); //Animated tile uses ArrayList in Level class as well as AnimatedTile class
    
  public static Tile spawn_water_river = new SpawnWaterTile1(Sprite.spawn_water_river);
  public static Tile spawn_water_corner_TL = new SpawnWaterTile1(Sprite.spawn_water_corner_TL);
  public static Tile spawn_water_corner_TR = new SpawnWaterTile1(Sprite.spawn_water_corner_TR);
  public static Tile spawn_water_corner_BR = new SpawnWaterTile1(Sprite.spawn_water_corner_BR);
  public static Tile spawn_water_corner_BL = new SpawnWaterTile1(Sprite.spawn_water_corner_BL);
  
  public static Tile spawn_water_side_l = new SpawnWaterTile1(Sprite.spawn_water_side_l);
  public static Tile spawn_water_side_r = new SpawnWaterTile1(Sprite.spawn_water_side_r);
  public static Tile spawn_water_side_t = new SpawnWaterTile1(Sprite.spawn_water_side_t);
  public static Tile spawn_water_side_b = new SpawnWaterTile1(Sprite.spawn_water_side_b);
  
  public static Tile spawn_water_edge_tl = new SpawnWaterTile1(Sprite.spawn_water_edge_tl);
  public static Tile spawn_water_edge_tr = new SpawnWaterTile1(Sprite.spawn_water_edge_tr);
  public static Tile spawn_water_edge_bl = new SpawnWaterTile1(Sprite.spawn_water_edge_bl);
  public static Tile spawn_water_edge_br = new SpawnWaterTile1(Sprite.spawn_water_edge_br);
  
  public static Tile spawn_cliff = new SpawnRockTile(Sprite.spawn_cliff); // used rock tile class since it contains solid = true
  public static Tile spawn_cliff_t = new SpawnRockTile(Sprite.spawn_cliff_t);
  public static Tile spawn_cliff_b = new SpawnRockTile(Sprite.spawn_cliff_b);
  public static Tile spawn_cliff_l = new SpawnRockTile(Sprite.spawn_cliff_l);
  public static Tile spawn_cliff_r = new SpawnRockTile(Sprite.spawn_cliff_r);
  public static Tile spawn_cliff_corner_tl = new SpawnRockTile(Sprite.spawn_cliff_corner_tl);
  public static Tile spawn_cliff_corner_tr = new SpawnRockTile(Sprite.spawn_cliff_corner_tr);
  public static Tile spawn_cliff_corner_bl = new SpawnRockTile(Sprite.spawn_cliff_corner_bl);
  public static Tile spawn_cliff_corner_br = new SpawnRockTile(Sprite.spawn_cliff_corner_br);
  public static Tile spawn_cliff_edge_tl = new SpawnRockTile(Sprite.spawn_cliff_edge_tl);
  public static Tile spawn_cliff_edge_tr = new SpawnRockTile(Sprite.spawn_cliff_edge_tr);
  public static Tile spawn_cliff_edge_bl = new SpawnRockTile(Sprite.spawn_cliff_edge_bl);
  public static Tile spawn_cliff_edge_br = new SpawnRockTile(Sprite.spawn_cliff_edge_br);

  
  public static Tile spawn_brick1 = new SpawnWallTile(Sprite.spawn_brick1); //Castle wall
  public static Tile spawn_brick2 = new SpawnBrickTile1(Sprite.spawn_brick2);
  public static Tile spawn_brick3 = new SpawnBrickTile1(Sprite.spawn_brick3);
  
  //House Tiles
  public static Tile spawn_door = new SpawnDoorTile(Sprite.spawn_door);
  public static Tile spawn_wall = new SpawnWallTile(Sprite.spawn_wall);
  public static Tile spawn_wood_floor = new SpawnBrickTile1(Sprite.spawn_wood_floor); //No collidor
  
  public static Tile spawn_crack1 = new SpawnCrackTile1(Sprite.spawn_crack1);
  public static Tile spawn_crack2 = new SpawnCrackTile1(Sprite.spawn_crack2);
  
  public static Tile zoneTileDoor = new ZoneTile(Sprite.mainZone); //switches player back to main level
  public static Tile zoneTile = new ZoneTile(Sprite.pamZone); //used to detect a change in levels
  
  public static Tile voidTile = new VoidTile(Sprite.voidSprite); //a blank tile used for unrendered parts of the map. Cant generate an actually void so MUST hold data, in other words black pixels

  // DEFINE THE COLORS USED ON THE PIXEL MAP "SPAWN_CASTLE" FOR PROPER TILE USAGE
  public static final int col_spawn_grass1 = 0xff37946e;
  public static final int col_spawn_grass2 = 0xff6abe30;
  public static final int col_spawn_grass3 = 0xff8f974a;
  public static final int col_spawn_grass4 = 0xff99e550;
  public static final int col_spawn_chicken_grass = 0xffbf9706;
  public static final int col_spawn_grassCollidor = 0xffbfd706;
  
  public static final int col_spawn_rock = 0xff000000;
  
  public static final int col_spawn_flower = 0xffd77bba;
  public static final int col_spawn_flower_pink = 0xffff0e69;
  
  public static final int col_spawn_sand = 0xffffb96e;
  
  public static final int col_spawn_water1 = 0xff639bFF;
  
  public static final int col_animWater = 0xff0000ff;

  //public static final int col_spawn_water_river = 0xff0000ff; //Water tile used for river in main level, matches corner pieces for water
 
  // Corner piece for water: TL = top left, TR = top right, BR = bottom right, BL = bottom left
  public static final int col_spawn_water_corner_TL = 0xff0000c7; 
  public static final int col_spawn_water_corner_TR = 0xff0000d4;
  public static final int col_spawn_water_corner_BR = 0xff0000de;
  public static final int col_spawn_water_corner_BL = 0xff0000f0;
  
  public static final int col_spawn_water_side_l = 0xff6e00f9; //Left side of edge of water
  public static final int col_spawn_water_side_r = 0xff6b00ed; //right side of edge of water
  public static final int col_spawn_water_side_t = 0xff6600e3; //top side of edge of water
  public static final int col_spawn_water_side_b = 0xff6000d6; //bottom side of edge of water
  
  public static final int col_spawn_water_edge_tl = 0xff00b5ff; //top left edge of water
  public static final int col_spawn_water_edge_tr = 0xff00c2ff;
  public static final int col_spawn_water_edge_br = 0xff009cff; //bottom right edge of water
  public static final int col_spawn_water_edge_bl = 0xff00a5ff;
  
  public static final int col_spawn_cliff = 0xff909090; //Cliff top surface 
  public static final int col_spawn_cliff_t = 0xffadadad; //Cliff top sprite color
  public static final int col_spawn_cliff_b = 0xffbababa; //Cliff bottom sprite color
  public static final int col_spawn_cliff_l = 0xff989898; //Cliff left sprite color
  public static final int col_spawn_cliff_r = 0xffa5a5a5; //Cliff right sprite color
  
  public static final int col_spawn_cliff_corner_tl = 0xff757575;
  public static final int col_spawn_cliff_corner_tr = 0xff707070;
  public static final int col_spawn_cliff_corner_bl = 0xff7a7a7a;
  public static final int col_spawn_cliff_corner_br = 0xff828282;
  
  public static final int col_spawn_cliff_edge_tl = 0xff636363;
  public static final int col_spawn_cliff_edge_tr = 0xff666666;
  public static final int col_spawn_cliff_edge_bl = 0xff545454;
  public static final int col_spawn_cliff_edge_br = 0xff5c5c5c;
  
  public static final int col_spawn_brick1 = 0xffac3232;
  public static final int col_spawn_brick2 = 0xff8f563b;
  public static final int col_spawn_brick3 = 0xff696a6a;
  
  public static final int col_spawn_door = 0xff3e5252;
  public static final int col_spawn_wall = 0xff665252;
  public static final int col_spawn_wood_floor = 0xff662c22;
  
  public static final int col_spawn_crack1 = 0xff663931;
  public static final int col_spawn_crack2 = 0xff595652;
  
  public static final int col_mainZone = 0xffea0000;
  public static final int col_pamZone = 0xff00ff00;

  public Tile(Sprite sprite) { //Every time tile is made this constructor has to be run, requires every tile to have a sprite
    this.sprite = sprite;
  }

  public void render(int x, int y, Screen screen) { //render method Tile class
    //Used for all tiles, even though every tile class has render method in it. Java needs this because worse case, if render method is NOT found in subclasses java will just run this method
  }

  public boolean solid() { // returns boolean (true or false) to determine if object has collidor
    return false; // by default, if method is NOT overriden in subclass it returns false
  }
  
  public boolean exit() {
	  return false;
  }
  
  public boolean inWater() { //returns default if method is NOT overriden in subclass
	  return false;
  }
}
