package game.level;

import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

import game.Game;
import game.entity.buildings.FarmHouse;
import game.entity.buildings.House;
import game.entity.mob.Chicken;
import game.entity.mob.Chicken2;
import game.entity.mob.DeadChicken;
import game.entity.mob.Player;
import game.entity.scenery.FarmField;

/*
 * This is main level in game, a town.
 */
public class TownLevel extends Level {
	
	private Game game;
	private int x, y;
	private boolean isDead = false;
		
	public TownLevel(String path) {
		super(path);		
	}

	protected void loadLevel(String path) {
		try {
			BufferedImage image = ImageIO.read(TownLevel.class.getResource(path));
			int w = width = image.getWidth();
			int h = height = image.getHeight();
			tiles = new int[w * h];
			image.getRGB(0, 0, w, h, tiles, 0, w);
		} catch(IOException e) {
			e.printStackTrace();
			System.out.println("ATTENTION! Could NOT load Town Level file");
		}
		
		//Buildings
		add(new House(54, 10)); //Entity #0
		add(new FarmHouse(140, 68));
		
		//Scenery
		add(new FarmField(134, 69));
		
		/*
		 * IMPORTANT: all entities past this point can be killed by player
		 */
		//NPCs
		add(new Chicken(148, 69)); //entity #3
		add(new Chicken(131, 67));
		add(new Chicken(136, 74));
		add(new Chicken(150, 70));
		add(new Chicken2(130, 73));
		add(new Chicken2(137, 79));
	}
	
	protected void generateLevel() {
	}
	
	public void checkExits(Player player) { //overrides method in Level class
		//Use player, since need to know which player changed levels
		//giving us also access to players location
		//(142, 72) and (143, 72)
		//System.out.println("key is " + Game.getKey());
		
		//Game.game.setLevel(Maps.pamHouse);
		//player = new Player("Unum The Exalted", 45, 55, Game.getKey()); //key is Keyboard class input, numbers are coordinates to spawn player
		//Game.game.getLevel().add(new Player(5, 6));
		


		System.out.println("Location: " + ((int)player.getX() >> 4) + " " + ((int)player.getY() >> 4));
		System.out.println("Called");
	}
	
}
