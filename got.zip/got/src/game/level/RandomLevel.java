package game.level;

import java.util.Random;

public class RandomLevel extends Level {

  private static final Random random = new Random(); // make random object, calls random method from class Random

  public RandomLevel(int width, int height){ //Constructor
    super(width, height); //super just means the parameters that are inputted into RandomLevel constructor will be inputted back into Level constructor in Level class

  }

  protected void generateLevel() { //protected method allows this generatelevel to override the generatelevel method in Level class
    for(int y = 0; y < height; y++) {
      for(int x = 0; x < width; x++) { // allow of generation of a particular tiles
        tilesInt[x + y * width] = random.nextInt(4); //generates out of '4' number [0, 1, 2, 3], allows to assign a value to a particular tile and randomly generate that tile, a water tile, rock, dirt, or grass tiles for instance

      // This will generate random tiles too all in one go, BUT doesn't allow control for generation of a spefic tile
      /*
      for( int i = 0; i < tiles.length; i++) {
        tiles[i] = random.nextInt[4]
      }
      */

      }
    }
  }
}
