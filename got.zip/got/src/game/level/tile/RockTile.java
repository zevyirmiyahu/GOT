package game.level.tile;

import game.graphics.Screen;
import game.graphics.Sprite;

public class RockTile extends Tile {
  public RockTile(Sprite sprite) {
    super(sprite);
  }

  public void render(int x, int y, Screen screen) { //Render method for grasstile
    screen.renderTile(x << 4, y << 4, this); //have to convert back to tile precise so mulitply by 16 (use bit wise operator)'this' because we are rendering grassTile and we are in the grassTile class
  }

  public boolean solid() { // returns boolean (true or false) to determ if object has collidor
    return true; // by default, if method is NOT overriden in subclass it returns false, rock is a solid
  }
}
