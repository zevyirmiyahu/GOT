package game.level.tile;

import game.graphics.Sprite;

/*
 * User to enter a different map level of the game
 */

public class ZoneTile extends Tile {
	
	public ZoneTile(Sprite sprite) {
		super(sprite);
	}
	
	public boolean exit() {
		return true;
	}

}
