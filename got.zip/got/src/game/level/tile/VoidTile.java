package game.level.tile;

import game.graphics.Sprite;
import game.graphics.Screen;

public class VoidTile extends Tile {

  public VoidTile(Sprite sprite) { //Constructor
    super(sprite);
  }

  public void render(int x, int y, Screen screen) { //Render method for void tile
    screen.renderTile(x << 4, y << 4, this); //'this' because we are rendering voidTile and we are in the grassTile class
  }

}
