package game.entity;

import java.util.Random;
import game.level.Level; // must import since using level variable
import game.graphics.Screen;
import game.graphics.Sprite;

//Any entity is any object in a games scene whether it is rendered to the screen or not. (bullets, guns, time..etc.)

public abstract class Entity {
  //entities posses the following things
  protected double x, y; // a position, may or may have this depending on wether entity has a sprite
  private boolean removed = false; //indicator of whether it is present in the level or not
  protected Level level; //because entities are in levels, an an entity will have protected level variable
  protected Random random = new Random(); // may have random variable, particularly for A.I.
  protected Sprite sprite;


  public void update() { // being run are 60 ups (updates per second)
  }

  public void render(Screen screen) { // puts entity on the screen
    if(sprite != null) screen.renderSprite((int) x, (int) y, sprite, true);
  }

  public void remove() { //removes the entity from the level
    //Remove from level
    removed = true;
  }
  

  public double getX() {
    return x;
  }

  public double getY() {
    return y;
  }

  public Sprite getSprite() {
    return sprite;
  }

  public boolean isRemoved() { // checks if it removed or not
    return removed;
  }

  public void init(Level level) { //initialize method
    this.level = level;
  }
}
