package game.entity.mob;

import java.util.List;

import game.graphics.AnimatedSprite;
import game.graphics.Screen;
import game.graphics.Sprite;
import game.graphics.SpriteSheet;
import game.util.Vector2i;
import game.entity.Entity;

//This entity will shoot ANY mob that is the closest whether is a player or NPC

public class MobShooter extends Mob {
	
	private AnimatedSprite down = new AnimatedSprite(SpriteSheet.dummy_down, 32, 32, 3); //For player movements
	private AnimatedSprite up = new AnimatedSprite(SpriteSheet.dummy_up, 32, 32, 3);
	private AnimatedSprite left = new AnimatedSprite(SpriteSheet.dummy_left, 32, 32, 3);
	private AnimatedSprite right = new AnimatedSprite(SpriteSheet.dummy_right, 32, 32, 3);
		
	private AnimatedSprite animSprite = down; //intial spawn direction is down
	private boolean walking = false; //determines whether NPC is moving.
	private int time = 0;
	private int xa = 0, ya = 0;
	
	private Entity rand = null; // random entity to be targeted
		
		
	// INITIALIZATION CODE: LOCTION, WHAT SPRITE TO ASSIGN
	public MobShooter(int x, int y) { //Constructor for spawn locations for the chaser
		this.x = x << 4; // convert from tile precision to pixel precision
		this.y = y << 4;
		sprite = Sprite.dummy;
	}
		
	// LOGIC ASPECTS OF MOB/NPC
	public void update() { //Update is where methods will be called like shoot, move ..etc. this where behavior is controlled
			
		//MOVEMENT LOGIC
		time++; //Since in update method, it will update 60 times per second, so multiple of 60 every second
		// EXPLANATION: time % 60 == 0; // = 1 second.;
		if(time % (random.nextInt(50) + 30) == 0) {
			//xa = -xa; //reverses direction
			xa = random.nextInt(3) - 1; //gives random number from 0 to 2, subtracting one give either -1, 0 or 1 randomly.
			ya = random.nextInt(3) - 1;
			// Place the second if so it happens one ever 60 secs
			if(random.nextInt(3) == 0) { //a one in three chances of stopping randomly to help chill out NPC from over walking
				xa = 0; //Allows NPC to be stationary
				ya = 0;
				time = 0; //MUST RESET TO AVOID GAME CRASH
			}
		}
		
		if(walking) animSprite.update();
		else animSprite.setFrame(0); // wont leave mob in mid walk
		if(ya < 0) {
			animSprite = up;
			dir = Direction.UP;
		} else if(ya > 0) {
			animSprite = down;
			dir = Direction.DOWN;
		}
		if(xa < 0) {
			animSprite = left;
			dir = Direction.LEFT;
		} else if(xa > 0) {
			animSprite = right;
			dir = Direction.RIGHT;
		}
		if(xa != 0 || ya != 0) {
			move(xa, ya);
			walking = true;
		} else {
			walking = false;
		}
		
		shootRandom();
	}
	
	private void shootRandom() {
		
		if(time % (30 + random.nextInt(91)) == 0) {
			List<Entity> entities = level.getEntities(this, 500);
			entities.add(level.getClientsPlayer()); //Same as below but add to list of entites
			int index = random.nextInt(entities.size()); //random index
			rand = entities.get(index); 
		}
		
		if(rand != null) { //ONLY if there are entities in range
			double dy = rand.getY() - y; 
			double dx = rand.getX() - x; //change in x is closest entity's x position minus shooter mob x position
			
			double shootDir = Math.atan2(dy, dx);
			shoot(x, y, shootDir);
		}
	}
		
	private void shootClosest() {
	    
		List<Entity> entities = level.getEntities(this, 500);
		//SHOOTING LOGIC
		entities.add(level.getClientsPlayer()); //Same as below but add to list of entites
		
		double min = 0; //minimum distance
		Entity closest = null; // closest Entity to MobShooter
		
		for(int i = 0; i < entities.size(); i++) {
			Entity e = entities.get(i);
			double distance = Vector2i.getDistance(new Vector2i(x, y), new Vector2i(e.getX(), e.getY())); //Distance between MobShooter and 'current' entities
			if(i == 0 || distance < min) {
				min = distance; //set for first loop and if new minimum distance is found
				closest = e; // closest entity become entity e
			}
		}
		
		if(closest != null) { //ONLY if there are entities in range
			double dy = closest.getY() - y; 
			double dx = closest.getX() - x; //change in x is closest entity's x position minus shooter mob x position
			
			double shootDir = Math.atan2(dy, dx);
			shoot(x, y, shootDir);
		}
	}
	
	// VISUAL ASPECTS OF MOB/NPC
	public void render(Screen screen) {
		sprite = animSprite.getSprites();
		screen.renderPlayerDynamic((int)x - 16, (int)y - 16, sprite);	
	}

}


