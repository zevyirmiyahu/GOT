package game.entity.mob;

import game.graphics.AnimatedSprite;
import game.graphics.Screen;
import game.graphics.Sprite;
import game.graphics.SpriteSheet;

public class Goon extends Mob {
	
	  private AnimatedSprite down = new AnimatedSprite(SpriteSheet.goon_down, 32, 48, 4); //For player movements
	  private AnimatedSprite up = new AnimatedSprite(SpriteSheet.goon_up, 32, 48, 4);
	  private AnimatedSprite left = new AnimatedSprite(SpriteSheet.goon_left, 32, 48, 4);
	  private AnimatedSprite right = new AnimatedSprite(SpriteSheet.goon_right, 32, 48, 4); 
	  private AnimatedSprite animSprite = down; //intial spawn direction is down
	  private boolean walking = false; //determines whether dummy NPC is moving.
	  private int time = 0;
	  private int xa = 0, ya = 0;


	  public Goon(int x, int y) { //Constructor, coordinates for Goon to spawn at
	    this.x = x << 4; //shifted 4 places same as multiplying by 16
	    this.y = y << 4;
	    sprite = Sprite.goon;
	  }

	  public void update() {
		  
	    time++; //Since in update method, it will update 60 times per second, so multiple of 60 every second
	    // EXPLANATION: time % 60 == 0; // = 1 second.;
	    if(time % (random.nextInt(50) + 30) == 0) {
	      //xa = -xa; //reverses direction
	      xa = random.nextInt(3) - 1; //gives random number from 0 to 2, subtracting one give either -1, 0 or 1 randomly.
	      ya = random.nextInt(3) - 1;
	      // Place the second if so it happens one ever 60 secs
	      if(random.nextInt(3) == 0) { //a one in three chances of stopping randomly to help chill out NPC from over walking
	        xa = 0; //Allows NPC to be stationary
	        ya = 0;
	        time = 0; //MUST RESET TO AVOID GAME CRASH
	      }
	    }
	    
	     
	    
	    if(walking) animSprite.update();
	    else animSprite.setFrame(0); // wont leave mob in mid walk
	    if(ya < 0) {
	      animSprite = up;
	      dir = Direction.UP;
	    } else if(ya > 0) {
	      animSprite = down;
	      dir = Direction.DOWN;
	     }
	    if(xa < 0) {
	      animSprite = left;
	      dir = Direction.LEFT;
	    } else if(xa > 0) {
	      animSprite = right;
	      dir = Direction.RIGHT;
	    }

	    if(xa != 0 || ya != 0) {
	      move(xa, ya);
	      walking = true;
	    } else {
	      walking = false;
	    } 
	  } 
	  

	  public void render(Screen screen) {
	    sprite = animSprite.getSprites();
	    screen.renderPlayerDynamic((int) x - 10, (int) y - 8, sprite);
	  }

}
