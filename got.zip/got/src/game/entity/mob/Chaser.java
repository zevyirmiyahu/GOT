package game.entity.mob;

//MORE ADVANCED AI FOR NPC/MOBS

import java.util.List;
import game.graphics.Screen;
import game.graphics.Sprite;
import game.graphics.AnimatedSprite;
import game.graphics.SpriteSheet;

public class Chaser extends Mob {
  private AnimatedSprite down = new AnimatedSprite(SpriteSheet.chaser_down, 32, 32, 3); //For player movements
  private AnimatedSprite up = new AnimatedSprite(SpriteSheet.chaser_up, 32, 32, 3);
  private AnimatedSprite left = new AnimatedSprite(SpriteSheet.chaser_left, 32, 32, 3);
  private AnimatedSprite right = new AnimatedSprite(SpriteSheet.chaser_right, 32, 32, 3);
  private boolean walking = false; //determines whether NPC is moving.
  private double speed = 0.8;

  private AnimatedSprite animSprite = down; //intial spawn direction is down
  private double xa = 0;
  private double ya = 0;

  public Chaser(int x, int y) { //Constructor for spawn locations for the chaser
    this.x = x << 4; // convert from tile precision to pixel precision
    this.y = y << 4;
    sprite = Sprite.chaser;
  }

  private void move() {
    xa = 0;
    ya = 0;

    //Player player = level.getClientsPlayer();
    List <Player> players = level.getPlayers(this, 100);
    if(players.size() > 0) {
      Player player = players.get(0); //Since only one player
      if((int)x < (int)player.getX()) xa += speed; // then move forward
      if((int)x > (int)player.getX()) xa -= speed; //MUST CAST X AND PLAYER.GETX() TO INTS OTHRWISE MOVEMENT IS NOT SMOOTH AND PRECISE!!!!
      if((int)y < (int)player.getY()) ya += speed;
      if((int)y > (int)player.getY()) ya -= speed;
    }
    if(xa != 0 || ya != 0) {
        move(xa, ya); // method from mob class
        walking = true;
      } else {
        walking = false;
      }

  }

  public void update() {
    move();
    if(walking) animSprite.update(); //this coupled with if statements below is only for direction, NOT the AI part of the NPC
    else animSprite.setFrame(0); // wont leave mob in mid walk
    if(ya < 0) {
      animSprite = up;
      dir = Direction.UP;
    } else if(ya > 0) {
      animSprite = down;
      dir = Direction.DOWN;
     } 
    if(xa < 0) {
      animSprite = left;
      dir = Direction.LEFT;
    } else if(xa > 0) {
      animSprite = right;
      dir = Direction.RIGHT;;
    }
  }

  public void render(Screen screen) {
    sprite = animSprite.getSprites(); //putting before rendering insures most updated version is displayed every time
    screen.renderMob((int) (x - 16), (int) (y - 16), this); //since its in Mob class this implies a Mob object is used, subtract 16 to help align with player
  }
}
