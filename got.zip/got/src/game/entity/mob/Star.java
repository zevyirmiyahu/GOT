package game.entity.mob;

import java.util.List;
import game.graphics.Screen;
import game.graphics.Sprite;
import game.graphics.AnimatedSprite;
import game.graphics.SpriteSheet;
import game.level.Node;
import game.util.Vector2i;

// More advanced Chaser that use A* algorithm

public class Star extends Mob {
	
	  private AnimatedSprite down = new AnimatedSprite(SpriteSheet.chaser_down, 32, 32, 3); //For player movements
	  private AnimatedSprite up = new AnimatedSprite(SpriteSheet.chaser_up, 32, 32, 3);
	  private AnimatedSprite left = new AnimatedSprite(SpriteSheet.chaser_left, 32, 32, 3);
	  private AnimatedSprite right = new AnimatedSprite(SpriteSheet.chaser_right, 32, 32, 3);
	  private boolean walking = false; //determines whether NPC is moving.
	  private double speed = 0.8;

	  private AnimatedSprite animSprite = down; //intial spawn direction is down
	  private double xa = 0;
	  private double ya = 0;
	  private List<Node> path = null; //default equals null
	  private int time = 0; //for A* algorithm efficiency

	  public Star(int x, int y) { //Constructor for spawn locations for the chaser
	    this.x = x << 4; // convert from tile precision to pixel precision
	    this.y = y << 4;
	    sprite = Sprite.chaser;
	  }

	  private void move() {
	    xa = 0;
	    ya = 0;
	    
	    int px = (int) level.getPlayerAt(0).getX(); //Players x position, LOCATIONS ARE IN PIXEL PRECISION
	    int py = (int) level.getPlayerAt(0).getY(); //Players y position
	    Vector2i start = new Vector2i((int)getX() >> 4, (int)getY() >> 4); //Must divide by 16 to convert from pixel precision to tile precision. A shift to the right by four 
	    Vector2i destination = new Vector2i(px >> 4, py >> 4);
	    path = level.findPath(start, destination); // ADD: if(time % 3 == 1) FOR EFFICIENCY. if statement is for efficiency purpose. It will only update path 20 updates per second
	    if(path != null) {
	    	if(path.size() > 0) {
	    		Vector2i vec = path.get(path.size() - 1).tile; //path.size() - 1 because A* Algorithm store the Nodes with the 1 element being closest to destination, thus we must beginning with last element in the arraylist
	    		if(x < (int)vec.getX() << 4) xa++; //multiplying 16 to vec.getX() converts to tile precision
	    		if(x > (int)vec.getX() << 4) xa--; //these four lines simply move Star mob to the above vector: vec
	    		if(y < (int)vec.getY() << 4) ya++;
	    		if(y > (int)vec.getY() << 4) ya--;
	    	}
	    }
	    
	    if(xa != 0 || ya != 0) {
	        move(xa, ya); // method from mob class
	        walking = true;
	      } else {
	        walking = false;
	      }

	  }

	  public void update() {
		time++; //increment, currently not needed but kept for possible future use
	    move();
	    if(walking) animSprite.update(); //this coupled with if statements below is only for direction, NOT the AI part of the NPC
	    else animSprite.setFrame(0); // wont leave mob in mid walk
	    if(ya < 0) {
	      animSprite = up;
	      dir = Direction.UP;
	    } else if(ya > 0) {
	      animSprite = down;
	      dir = Direction.DOWN;
	     } 
	    if(xa < 0) {
	      animSprite = left;
	      dir = Direction.LEFT;
	    } else if(xa > 0) {
	      animSprite = right;
	      dir = Direction.RIGHT;
	      time = 0; //MUST RESET TO AVOID GAME CRASH
	    }
	  }

	  public void render(Screen screen) {
	    sprite = animSprite.getSprites(); //putting before rendering insures most updated version is displayed every time
	    screen.renderMob((int) (x - 16), (int) (y - 16), this); //since its in Mob class this implies a Mob object is used, subtract 16 to help align with player
	  }
	}

