package game.entity.mob;

import game.entity.Entity; //need to import since this class extends class Entity
import game.entity.projectile.Projectile;
import game.entity.projectile.WizardProjectile;
import game.graphics.Screen;

// a mob is any entity in the game that moves (characters, enemies etc.)

public abstract class Mob extends Entity { // because we dont need to instantiate it
  // MOB Sprite not being used.   protected Sprite sprite; //mob NEEDS a sprite object, also good programming practices to use protected to restrict access, helps avoid accessing wrong variables
  // Alternative for direction below
  //protected int dir = 0; //directions, 0 is north, 1 is east, 2 is south and 3 is west
  protected boolean moving = false; //mob have animation movement, this establishes if mob is moving
  protected boolean walking = false;
  protected int health; //hp/health of mobs
  
  protected enum Direction {
    UP, DOWN, LEFT, RIGHT
  }

  protected Direction dir;

  // Move to Level class because need to make projectiles seperate from entities
  //protected List<Projectile> projectiles = new ArrayList<Projectile> (); //putting this in mob allows to trace back which projectile belongs to which mob

  //Methods of class Mob
  public void move(double xa, double ya) { //move method

    if(xa != 0 && ya != 0) {
      move(xa, 0);
      move(0, ya);
      return;
    }

    if(xa > 0) dir = Direction.RIGHT;
    if(xa < 0) dir = Direction.LEFT;
    if(ya > 0) dir = Direction.DOWN;
    if(ya < 0) dir = Direction.UP;

    /*
    if(xa > 0) dir = 1; //east direction
    if(xa < 0) dir = 3; //west direction
    if(ya > 0) dir = 0; //south direction
    if(ya < 0) dir = 2; //north direction
    */

    while(xa != 0) {
      if(Math.abs(xa) > 1) { //same as if(xa - 1) > 0) just checking if subtracting one is positive then can move
        if(!collision(abs(xa), ya)) {
          this.x += abs(xa);
        }
        xa -= abs(xa);
      } else {
        if(!collision(abs(xa), ya)) {
          this.x += xa;
        }
        xa = 0;
      }
    }
    while(ya != 0) {
      if(Math.abs(ya) > 1) { //same as if(ya - 1) > 0) just checking if subtracting one is positive then can move
        if(!collision(xa, abs(ya))) {
          this.y += abs(ya);
        }
        ya -= abs(ya);
      } else {
    	  if(!collision(xa, abs(ya))) {
    		  this.y += ya;
    	  }
        ya = 0;
      }
    }
  }
  private int abs(double value) {
    if(value < 0) return -1;
    return 1;
  }

    /* New technic used above to solve problem
    // 1, 2, 3, 4, etc. ALLOWS!
    // 0.472, 2.5, 5.6, etc. DOESN'T ALLOW! //the limitation of a for loop, must be integers
    for(int x = 0; x < Math.abs(xa); x++) {// MORE PRECISE COLLISION METHOD INCASE MOB IS MOVING FAST
      if(!collision(abs(xa), ya)) {
        this.x += abs(xa);
      }
    }
    for(int y = 0; y < Math.abs(ya); y++) {
      if(!collision(xa, abs(ya))) {
        this.y += abs(ya);
      }
    }
  }
  private int abs(double value) {
    if(value < 0) return -1;
    return 1;
  }
  */

  public abstract void update(); //obviously need to update the mob, abstract because we dont have to implement the method here can have in any other class
  public abstract void render(Screen screen);

  protected void shoot(double x, double y, double dir) {
    //dir *= 180 / Math.PI; //Math.toDegrees(angle); // converts angle from radians to degrees
    Projectile p = new WizardProjectile(x, y, dir);
    level.add(p);

  }

  private boolean collision(double xa, double ya) { // determines if mob can pass from object in game or not
  	boolean solid = false;
  	//double xt = 0, yt = 0;
	  for(int c = 0; c < 4; c++) { // c represents a corner of the tile thus allowing for a slightly more complex collidor system, and if any of those corners of the tile belongs to a solid tile then it sets solid = true
		  /*
		  if(xa >= 0) xt = ((x + xa) - c % 2 * 15 + 16) / 16;
		  if(xa < 0) xt = ((x + xa) - c % 2 * 15 + 1) / 16;
		  if(ya >= 0) yt = ((y + ya) - c / 2 * 15 - 16) / 16;
		  if(ya < 0) yt = ((y + ya) - c / 2 * 15 + 24) / 16;
		*/
		  double xt = ((x + xa - 4.5) - c % 2 * 5 - 7) / 16; // changes collision parameters
		 double yt = ((y + ya - 3) - c / 2 * 5 + 3) / 16;
		  
		  
		  int ix = (int) Math.ceil(xt); //getTile method needs int
		  int iy = (int) Math.ceil(yt);
		  if(c % 2 == 0) ix = (int) Math.floor(xt); // avoids rounding error and proper dispersion of particles
		  if(c / 2 == 0) iy = (int) Math.floor(yt);
		  if(level.getTile(ix, iy).solid()) solid = true;  // divided x+xa and y+ya by 16 to convert to tile precision from pixel percision x is current location, y is current location. xa is position player will move, ya is location player will move
	  }
	  return solid;
  }
}
