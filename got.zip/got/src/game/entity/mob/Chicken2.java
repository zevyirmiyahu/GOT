package game.entity.mob;

import game.graphics.AnimatedSprite;
import game.graphics.Screen;
import game.graphics.Sprite;
import game.graphics.SpriteSheet;

/*
 * This chicken Mob walks only back and forth along x-axis
 */

public class Chicken2 extends Mob {

	private AnimatedSprite down = new AnimatedSprite(SpriteSheet.chicken_down, 16, 32, 3); //For player movements
	private AnimatedSprite up = new AnimatedSprite(SpriteSheet.chicken_up, 16, 32, 3);
	private AnimatedSprite left = new AnimatedSprite(SpriteSheet.chicken_left, 16, 32, 3);
	private AnimatedSprite right = new AnimatedSprite(SpriteSheet.chicken_right, 16, 32, 3);
	private AnimatedSprite animSprite = down; //intial spawn direction is down
	private boolean walking = false; //determines whether dummy NPC is moving.
	private int time = 0;
	private  int xa = 0, ya = 0;

	public Chicken2(int x, int y) { //Constructor, coordinates for Dummy to spawn at
	    this.x = x << 4; //shifted 4 places same as multiplying by 16
	    this.y = y << 4;
	    sprite = Sprite.chicken;
	  }
	  
	public void update() {
		
		time++; //Since in update method, it will update 60 times per second, so multiple of 60 every second

		//Makes Mob walk in a square
		/*
		 * 0 = right, 1 = up, 2 left, 3 down
		 */
	
		if(time % 60 == 0) xa = 1;
		if(time % 120 == 0) {
			xa = -xa;
		}
		if(time % 180 == 0) {
			xa = 0;
			time = 0; //reset time
		}
		
				
	//SpawnCollidorTile.solid(Sprite.chicken);
  	if(walking) animSprite.update();
  	else animSprite.setFrame(0); // wont leave mob in mid walk
	    
	    if(ya < 0) {
	      animSprite = up;
	      dir = Direction.UP;
	    } else if(ya > 0) {
	      animSprite = down;
	      dir = Direction.DOWN;
	     }	  
	    if(xa < 0) {
	      animSprite = left;
	      dir = Direction.LEFT;
	    } else if(xa > 0) {
	      animSprite = right;
	      dir = Direction.RIGHT;
	    }
  
	    if(xa != 0 || ya != 0) {
	      move(xa, ya);
	      walking = true;
	    } else {
	      walking = false;
	    }
  }

  

	  public void render(Screen screen) {
	    sprite = animSprite.getSprites();
	    screen.renderPlayerDynamic((int) x - 16, (int) y - 16, sprite);
	  }
}
