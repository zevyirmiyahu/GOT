package game.entity.mob;

/*
 * Currently, not in use
 */

import game.graphics.AnimatedSprite;
import game.graphics.Screen;
import game.graphics.SpriteSheet;

public class DeadChicken extends Mob {
	
	private boolean isDead = false;
	
	private AnimatedSprite dead = new AnimatedSprite(SpriteSheet.chicken_dead, 112, 16, 7);
	
	public DeadChicken(int x, int y) {
		this.x = x << 4;
		this.y = y << 4;
	}

	public void update() {
		dead.update();
	}

	public void render(Screen screen) {
		sprite = dead.getSprites();
		screen.renderSprite((int)x, (int)y, sprite, true);		
	}	
}
