package game.entity.spawner;

import game.entity.Entity;
import game.level.Level;

// Class emits particles from locations (in general spawns them and can emit other things, characters etc.)

public class Spawner extends Entity {

  public enum Type { //creates custome varaible that can be equal to either MOB or PARTICLE
    MOB, PARTICLE;
  }

  protected Type type;

  public Spawner(int x, int y, Type type, int amount, Level level) { //Constructor x and y location to spawn, an entity to spawn and the amount of entities
    init(level);
    this.x = x;
    this.y = y;
    this.type = type;
  }

}
