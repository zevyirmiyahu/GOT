package game.entity.particle;

import game.entity.Entity;
import game.graphics.Screen;
import game.graphics.Sprite;


public class Particle extends Entity { // particle extends entity because we have array list in the level class name entities and will art particles to that list. Thus, adding them to the level
  private Sprite sprite;
  private int life;
  private int time = 0; //counter

  protected double xx, yy, zz; // xx and yy is actual x and y postion in type double, xa the x amount moved, ya the y amount moved
  protected double xa, ya, za;
  // Don't need x and y since they are in Entity class

  public Particle(int x, int y, int life) { //Constructor for single particle
    this.x = x;
    this.y = y;
    this.xx = x;
    this.yy = y;
    this.life = life + (random.nextInt(30) - 20); //allows for varied particle lifes
    sprite = Sprite.particle_normal;

    this.xa = random.nextGaussian(); // gives random number between -1 and 1, normally distributed value
    this.ya = random.nextGaussian();
    this.zz = random.nextFloat() + 2.0;
  }
  /* //Delete entire constructor will implement in by Spawner class
  public Particle(int x, int y, int life, int amount) {//Constructor, x,y location particles orginate, life is how long they last for, amount is how many particles to render
    this(x, y, life); // Runs the constructor above
    for(int i = 0; i < amount - 1; i++) { // -1 because the above constructor has already added the first particle
      particles.add(new Particle(x, y, life));
    }
    particles.add(this); // adds an istances of this class with the above properties into the array list particles

  } */

//overrides Entity class methods
public void update() { // being run are 60 ups (updates per second)
  time++;
  if(time >= 7000) time = 0; //Makes the time counter reset if max number is exceeded so game doesn't crash
  //if(time >= Integer.MAX_VALUE - 1) time = 0; //Second way, makes the time counter reset if max number is exceeded so game doesn't crash
  if(time > life) remove();
  za -= 0.1;

  if(zz < 0) {
    zz = 0;
    za *= -0.8;
    xa *= 0.4; //with every bounce half the rate on the x axis
    ya *= 0.5; //with every bounce half the rate on the y axis

  }
  move(xx + xa, (yy + ya) + (zz + za));
}

private void move(double x, double y) { // if collision reverse every direction
  if(collision(x, y)) {
    this.xa *= -0.5;
    this.ya *= -0.5;
    this.za *= -0.5;

  }
  this.xx += xa;
  this.yy += ya;
  this.zz += za;
}

public boolean collision(double x, double y) {
  boolean solid = false;
  for(int c = 0; c < 4; c++) { // c represents a corner of the tile thus allowing for a slightly more complex collidor system, and if any of those corners of the tile belongs to a solid tile then it sets solid = true
    double xt = (x - c % 2 * 16) / 16; // changes collision parameters
    double yt = (y - c / 2 * 16) / 16;
    int ix = (int) Math.ceil(xt); //getTile method needs int
    int iy = (int) Math.ceil(yt);
    if(c % 2 == 0) ix = (int) Math.floor(xt); // avoids rounding errror and proper dispersion of particles
    if(c / 2 == 0) iy = (int) Math.floor(yt);
    if(level.getTile(ix, iy).solid()) solid = true;
  }
  return solid;
}

public void render(Screen screen) { // puts particles on the screen
  screen.renderSprite((int)xx, (int)yy - (int)zz, sprite, true);
}



}
