package game.entity.buildings;

import game.entity.mob.Mob;
import game.graphics.Screen;
import game.graphics.Sprite;

public class House extends Mob {

	 public House(int x, int y) { //Constructor, coordinates for house to spawn at
		    this.x = x << 4; //shifted 4 places same as multiplying by 16
		    this.y = y << 4;
		    sprite = Sprite.house;
		  }

	public void update() {	
	}
	
	public void render(Screen screen) {
		screen.renderSprite((int)x, (int)y, sprite, true);
		
	}
	
}
