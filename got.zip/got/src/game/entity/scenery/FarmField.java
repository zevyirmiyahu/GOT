package game.entity.scenery;

import game.entity.mob.Mob;
import game.graphics.Screen;
import game.graphics.Sprite;

public class FarmField extends Mob {
	
	public FarmField(int x, int y) {
		this.x = x << 4; //spawn location x and shifted 4 places same as multiplying by 16
		this.y = y << 4; //Spawn location y
		sprite = Sprite.farmField;
	}
	
	public void update() {
	}
	
	public void render(Screen screen) {
		screen.renderSprite((int)x, (int)y, sprite, true);
	}

}
