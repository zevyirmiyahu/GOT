package game.menus;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.net.URL;

import javax.swing.ImageIcon;

import game.Game;
import game.graphics.Font;
import game.graphics.Screen;
import game.graphics.SpriteSheet;

/*
 * Opening Scene menu after Play button is pressed on main menu
 */

public class OpeningMenu extends Thread {
	
	private static Image image;
	private int width = (Game.getGameWidth() + 80) * Game.getGameScale(); // Width of opening menu
	private int height = Game.getGameHeight() * Game.getGameScale(); //Height of opening menu
	
	private int yStart = height + 1; // Height at which text starts
	private int xOffset = 200;
	private int yOffset = 50; // for line spacing
	private static int scroll;
	private int time;
	
	private String s1 = "Time has fractured... ";
	private String s2 = "Past, Present and Future... are now one.";	
	private String s3 = "The Gods of Time have descended to mend";
	private String s3_Cont = "the world. ";
	private String s4 = "The God of the Past - Yenud The Bold";
	private String s5 = "The God of the Present - Unam The Exalted";
	private String s6 = "The God of the Future - Asu The Powerful";
	private String s7 = "...The adventure awaits!";
	
	protected Font font; // Custom font
	protected Screen screen;
	
	
	public OpeningMenu(Font font) {
		this.font = font;
		LoadBackground();
	}
	
	
	public void LoadBackground() {
		//screen = new Screen(width, height); //Overrides screen dimenions in Game class	
		try {
			URL imgURL = this.getClass().getResource("/game/res/OpeningMenu.png");
			image = new ImageIcon(imgURL).getImage(); 
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public void update() {
		time++;
		if(time % 2  == 0) scroll = scroll - 1; // Slows scroll
		if(time > 7000) time = 0; // Avoid crashes
		if(scroll == -(yStart + yOffset * 8 + 1)) { //the inverse value of the last lines height plus 1
			Game.state = Game.STATE.GAME;
		}
		
	}

	
	public void render(Screen screen) {
		screen.renderSheet(10, 70, SpriteSheet.OpeningMenuBackground, false);
	}
	
	public void render(Graphics g) {
		
		g.drawImage(image, -53, 0, (Game.getGameWidth() - 80) * Game.getGameScale(), Game.getGameHeight() * Game.getGameScale(), null);
	 
		g.setColor(Color.WHITE);
		g.setFont(new java.awt.Font("Monospaced", 1, 20));	
		
		
		for(int i = 1; i < 9; i++) {
			
			if(i == 1)
				g.drawString(s1, (width - xOffset) / 2, yStart + yOffset + scroll);
			if(i == 2)
				g.drawString(s2, (width - xOffset) / 2,  yStart + yOffset * i + scroll); //y-offset is 40px
			if(i == 3)
				g.drawString(s3, (width - xOffset) / 2, yStart + yOffset * i + scroll);
			if(i == 4)
				g.drawString(s3_Cont, (width - xOffset) / 2, yStart + yOffset * i + scroll);
			if(i == 5)
				g.drawString(s4, (width - xOffset) / 2, yStart + yOffset * i + scroll);
			if(i == 6)
				g.drawString(s5, (width - xOffset) / 2, yStart + yOffset * i + scroll);
			if(i == 7)
				g.drawString(s6, (width - xOffset) / 2, yStart + yOffset * i + scroll);
			if(i == 8)
				g.drawString(s7, (width - xOffset) / 2, yStart + yOffset * i + scroll);
		}
	}
}
