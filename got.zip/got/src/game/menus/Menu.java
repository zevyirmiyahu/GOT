package game.menus;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.net.URL;

import javax.swing.ImageIcon;

import game.Game;
import game.input.Mouse;

/*
 * Handles the main start up menu screen. Note Button action is handled in the Mouse class
 */


public class Menu {
		
	private double moveScale; // Scale at which background moves
	
	private Image image; 
	
	private double x;
	private double y;
	private double dx;
	private double dy;
	
	private static int buttonWidth = 100; //Button width
	private static int buttonHeight = 50; //Button height
	
	private static int positionX = Game.getWindowWidth() / 2 ; // x position of button
	private static int positionY = 150; // y position of button
	
	//Menu Buttons
	public Rectangle playButton = new Rectangle(positionX + 350, positionY, buttonWidth, buttonHeight);
	public Rectangle helpButton = new Rectangle(positionX + 350, positionY + 100, buttonWidth, buttonHeight);
	public Rectangle quitButton = new Rectangle(positionX + 350, positionY + 200, buttonWidth, buttonHeight);

	public static boolean insidePlayButton = false;
	public static boolean insideHelpButton = false;
	public static boolean insideQuitButton = false;
	
	// Getters
	public static int getX() {
		return positionX;
	}
	
	public static int getY() {
		return positionY;
	}
	
	public static int getWidth() {
		return buttonWidth;
	}
	
	public static int getHeight() {
		return buttonHeight;
	}
	
	
	public Menu() {
		/*
		 * Not needed
		 *
		 setPosition(0, 0); //initialize position
		 */
		
		Mouse mouse = new Mouse();
		
		
		try {
			/*
			 * IMPORTANT: This code loads a gif image and properly plays the gif file
			 */
			URL imgURL = this.getClass().getResource("/game/res/GameScene.gif");
			image = new ImageIcon(imgURL).getImage(); //must be imageIcon to load gif properly, image alone won't work

		} catch(Exception e) {
			e.printStackTrace();
		}		
	} 


	// To automatically scroll background
	public void setVector(double dx, double dy) {
		this.dx = dx;
		this.dy = dy;
	}
	
	/*
	 *  Don't acutally need x, can be initalized at tope of code, kept for possible future use
	 *
	public void setPosition(double x, double y) {
		this.x = (x * moveScale) % (Game.width + 80); // mod resets so image doesn't go off screen
		//this.y = (y * moveScale) % Game.height;
	} 
	*/
	 
	
	public void update() {
		// Mouse button is clicked
		if(Mouse.getButton() == 1) {
			
			if(Game.state == Game.STATE.MENU) { //Prevents execution during game play after menu
				// Play Button  clickable area
				if(Mouse.getX() > Menu.getX() + 350 && Mouse.getX() < Menu.getX() + 350 + Menu.getWidth()) {
					if(Mouse.getY() > Menu.getY() && Mouse.getY() < Menu.getY() + Menu.getHeight()) {
						Game.state = Game.STATE.OPENING_MENU;
					}
				}
		
				// Help Button clickable area
				if(Mouse.getX() > Menu.getX() + 350 && Mouse.getX() < Menu.getX() + 350 + Menu.getWidth()) {
					if(Mouse.getY() > Menu.getY() + 100 && Mouse.getY() < Menu.getY() + 100 + Menu.getHeight()) {
						System.out.println("Help was pressed");
					}
				}
		
				// Quit Button clickable area
				if(Mouse.getX() > Menu.getX() + 350 && Mouse.getX() < Menu.getX() + 350 + Menu.getWidth()) {
					if(Mouse.getY() > Menu.getY() + 200 && Mouse.getY() < Menu.getY() + 200 + Menu.getHeight()) {
						System.exit(1);		
					}
				}
			}
		}
	}
	
	/*
	// Initializing function
	public void init() {
		
		image  = new BufferedImage(Game.getWindowWidth(), Game.getWindowHeight(), BufferedImage.TYPE_INT_RGB);
		try {
			bg = new Background("/game/res/Sky.gif", 1);
			bg.setVector(-0.1, 0);	
		} catch(Exception e) {
			e.printStackTrace();
		}
	} */
		
	
	public void render(Graphics g) {
		
		Graphics2D g2d = (Graphics2D)g; //cast g to 2D graphics
		
		/*
		 * First, image of background
		 * Add 80 pixels back to cover void of the UI interface
		 * must double (int)x to compensate for slow motion
		 */
		g.setColor(new Color(0x4c4c4c));
		g.fillRect(Game.getGameWidth(), 0, (Game.getGameWidth() + 30) * Game.getGameScale(), Game.getGameHeight() * Game.getGameScale());
		
		g.drawImage(image, 0, 0, (Game.getGameWidth() - 30) * Game.getGameScale(), Game.getGameHeight() * Game.getGameScale(), null);

		//g.drawImage(image, 0, 0, (Game.width + 80) * Game.scale, Game.height * Game.scale, null);
		//g.drawImage(image, 2 * (int)x + (Game.width + 80) * Game.scale, 0, 2*(int)x + (Game.width + 80) * Game.scale, (int)y + Game.height * Game.scale, null);
		
		/*
		 * Since background is scrolling must redraw on opposite side to refill screen
		 *  x < 0 must draw extra image to the right
		 *  Don't need x > 0 case since scrolling is only to left
		 *  x > 0 must draw extra image to the left
		 *
		if(x < 0.0) {
			g.drawImage(image, (int)x + (Game.width + 80) * Game.scale, 0, (int)x + (Game.width + 80) * Game.scale, (int)y + Game.height * Game.scale, null);
		}
		*
		 * Don't need x > 0 case
		 * 
		if(x > 0) {
			g.drawImage(image, (int)x, 0, (int)x + (Game.width + 80) * Game.scale, (int)y + Game.height * Game.scale, null);
		} */
	
		
						
		Font font = new Font("impact", Font.PLAIN, 40);
		g.setFont(font);
		g.setColor(new Color(0xffffff)); //White
		/*
		 * Or can use Color.WHITE
		 */
		//g.setColor(Color.WHITE); 
		
		g.drawString("The God's", positionX + 320, 60); //Eternal days and Forever Nights
		
		Font font2 = new Font("impact", Font.PLAIN, 20);
		
		g.setFont(font2);
		g.drawString("of", positionX + 390, 90);
		
		g.setFont(font);
		g.drawString("Time", positionX + 360, 130);
		
		Font buttonFont = new Font("arial", Font.BOLD, 30);
		g.setFont(buttonFont);
		
		g.drawString("Play", playButton.x + buttonWidth / 5, playButton.y + 2 * buttonHeight / 3);
		g2d.draw(playButton);
		
		g.drawString("Help", playButton.x + buttonWidth / 5, playButton.y + 100 + 2 * buttonHeight / 3);
		g2d.draw(helpButton);
		
		g.drawString("Quit", playButton.x + buttonWidth / 5, playButton.y + 200 + 2 * buttonHeight / 3);
		g2d.draw(quitButton);
		
		// Draws Mouse coordinates to screen
		//g.drawString("( " + Mouse.getX() +", " + Mouse.getY() + " )", Mouse.getX(), Mouse.getY());
		
	}
}
