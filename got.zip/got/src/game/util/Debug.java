package game.util;

import game.graphics.Screen;

/*Static class, this will never be instantiated
* Contains tools for debugging game
*/

public class Debug {
	
	private Debug() {
	}
	
	//used to visualize boundaries within the game
	public static void drawRect(Screen screen, int x, int y, int width, int height, boolean fixed) {
		drawRect(screen, x, y, width, height, 0xff0000, fixed); // color is set to red
	}
	
	public static void drawRect(Screen screen, int x, int y, int width, int height, int color, boolean fixed) {
		screen.drawRect(x, y, width, height, color, fixed);
	}
}
