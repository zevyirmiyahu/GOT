package game.input;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

//This class handles all keyboard input from user

public class Keyboard implements KeyListener { //implements keyListener interface that waits for inputs
  private boolean[] keys = new boolean[120];
  public boolean up, down, left, right;

  public void update() { //check to see if a key has been pressed, released
    up = keys[KeyEvent.VK_UP] || keys[KeyEvent.VK_W];
    down = keys[KeyEvent.VK_DOWN] || keys[KeyEvent.VK_S];
    left = keys[KeyEvent.VK_LEFT] || keys[KeyEvent.VK_A];
    right = keys[KeyEvent.VK_RIGHT] || keys[KeyEvent.VK_D];

  }

  public void keyPressed(KeyEvent e) {
    keys[e.getKeyCode()] = true;
  }

  public void keyReleased(KeyEvent e) {
    keys[e.getKeyCode()] = false;

  }

  public void keyTyped(KeyEvent e) {

  }
}
