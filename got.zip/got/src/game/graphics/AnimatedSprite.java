package game.graphics;

//Class used to automate sprite processes.

public class AnimatedSprite extends Sprite {

  private int frame = 0;
  private Sprite sprite;
  private int rate = 5;
  private int time = 0;
  private int length = -1; //the amount of frames in the animation, set to -1, because cant have animation of zero lenght, otherwise it's not in existence

  public AnimatedSprite(SpriteSheet sheet, int width, int height, int length) {
    super(sheet, width, height);
    this.length = length;
    sprite = sheet.getSprites()[0];
    if(length > sheet.getSprites().length) System.err.println("ERROR! Length of animation is too long!");
  }

  public void update() {
    time++;
    if(time % rate == 0) {
      if(frame >= length - 1) frame = 0; //resets the frames
      else frame++;
      sprite = sheet.getSprites()[frame];
    }
  }

  public Sprite getSprites() {
    return sprite;
  }

  public void setFrameRate(int frames) {
    rate = frames;
  }

  public void setFrame(int index) {
    if(index > sheet.getSprites().length - 1) {
      System.err.println("Index out of bounds" + this); // this gives exact memory address
      return;
    }
    sprite = sheet.getSprites()[index]; //get particular frame of player to be rendered
  }
}
