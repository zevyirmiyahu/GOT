package game.graphics;

import java.util.Random;
import game.level.tile.Tile;
import game.entity.projectile.Projectile;
import game.graphics.SpriteSheet;
import game.entity.mob.Mob;

//This is essentially the rendering class. Contains everything needs to render to the screen
//graphics subpackage/subfolder contains all classes associated with the graphics of the game
// Class specifies colors to be displayed on the screen

public class Screen {
  public int width, height; //Width and height of the screen
  public int[] pixels; //array that contains all the pixel data
  public final int MAP_SIZE = 64;
  public final int MAP_SIZE_MASK = MAP_SIZE - 1;
  public int xOffset, yOffset; //Offset of the screen attributed to the player
  public int[] tiles = new int[MAP_SIZE * MAP_SIZE]; // 64x64 size, this is the map
  private Random random = new Random();
  
  private final int ALPHA_COL = 0x000000; //Alpha channel color NOT to be rendered (void)
  

  public Screen(int width, int height) { //Constructor for class Screen, creates 1 pixel for each integer in area. Need width * height number of pixels ( the amount on the screen)
    this.width = width;
    this.height = height;
    pixels = new int[width * height]; // 50,400 integers, the amount of pixels on the screen that is stored in this array

    for(int i = 0; i < MAP_SIZE * MAP_SIZE; i++) {
      tiles[i] = random.nextInt(0xfffff); //color white, randomly choosing any color
      tiles[0] = 0;
    }
  }

  public void clear() { //clears the screen by setting all pixels to black
    for(int i = 0; i < pixels.length; i++) {
      pixels[i] = 0; // sets pixel to black
    }
  }

  public void renderSheet(int xp, int yp, SpriteSheet sheet, boolean fixed) { //sprite is glued to map
    if(fixed) {
      xp -= xOffset; //makes sprite move with the map
      yp -= yOffset;
    }
    for(int y = 0; y < sheet.SPRITE_HEIGHT; y++) {
      int ya = y + yp;
      for(int x = 0; x < sheet.SPRITE_WIDTH; x++) {
        int xa = x + xp;
        if(xa < 0 || xa >= width || ya < 0 || ya >= height) continue; //stops from drawing if its outside of screen
        pixels[xa + ya * width] = sheet.pixels[x + y * sheet.SPRITE_WIDTH];
      }
    }
  }
  
  //used to render text of different color	
  public void renderTextCharacter(int xp, int yp, Sprite sprite, int color, boolean fixed) { //sprite is glued to map
	    if(fixed) {
	      xp -= xOffset; //makes sprite move with the map
	      yp -= yOffset;
	    }
	    for(int y = 0; y < sprite.getHeight(); y++) {
	      int ya = y + yp;
	      for(int x = 0; x < sprite.getWidth(); x++) {
	        int xa = x + xp;
	        if(xa < 0 || xa >= width || ya < 0 || ya >= height) continue; //stops from drawing if its outside of screen
	        int col = sprite.pixels[x + y * sprite.getWidth()]; //pixel color that is being rendered at the moment
	        if(col != ALPHA_COL) pixels[xa + ya * width] = color; //Only renders if NOT the alpha Channel
	      }
	    }
	  }
  
  public void renderSprite(int xp, int yp, Sprite sprite, boolean fixed) { //sprite is glued to map
    if(fixed) {
      xp -= xOffset; //makes sprite move with the map
      yp -= yOffset;
    }
    for(int y = 0; y < sprite.getHeight(); y++) {
      int ya = y + yp;
      for(int x = 0; x < sprite.getWidth(); x++) {
        int xa = x + xp;
        if(xa < 0 || xa >= width || ya < 0 || ya >= height) continue; //stops from drawing if its outside of screen
        int col = sprite.pixels[x + y * sprite.getWidth()]; //pixel color that is being rendered at the moment
        if(col != ALPHA_COL) pixels[xa + ya * width] = col; //Only renders if NOT the alpha Channel
      }
    }
  }

/* This Method no longer needed

  public void render(int xOffset, int yOffset) {
    for (int y = 0; y < height; y++) {
      int yp = y + yOffset; // yp is y pixel
      if(yp < 0 || yp >= height) continue;
        for (int x = 0; x < width; x++) {
          int xp = x + xOffset; // xp is x pixel
          if(xp < 0 || xp >= width) continue;
          pixels[xp + yp * width] = Sprite.grass.pixels[(x & 15) + (y & 15) * Sprite.grass.SIZE];

      }
    }
  }
  */

  //NOT USED/NEEDED. MOVED ROTATION METHOD TO SPRITE CLASS.
  /*
  // Used for rotating a sprite, particularly a projectile sprite
  public void renderProjectile(int xp, int yp, Projectile p, double angle) {
		xp -= xOffset;
		yp -= yOffset;
			for (int y = 0; y < p.getSpriteSize(); y++) { //getSpriteSize() method in Porjectile class
				int ya = y + yp;
				for (int x = 0; x <p.getSpriteSize(); x++) {
					int xa = x + xp;
					if (xa < -p.getSpriteSize() || xa >= width || ya < 0 || ya >= height ) break;
					if (xa < 0) xa = 0;
					int[] rpixels = rotate(p.getSprite().pixels, p.getSpriteSize(), p.getSpriteSize(), angle); //rotated pixels
					int col = rpixels[x + y * p.getSprite().SIZE];
					if(col != ALPHA_COL) pixels[xa + ya * width] = col;
				}
			}
    } */
  
  
  public void renderProjectile(int xp, int yp, Projectile p) {
		xp -= xOffset;
		yp -= yOffset;
			for (int y = 0; y < p.getSpriteSize(); y++) { //getSpriteSize() method in Porjectile class
				int ya = y + yp;
				for (int x = 0; x <p.getSpriteSize(); x++) {
					int xa = x + xp;
					if (xa < -p.getSpriteSize() || xa >= width || ya < 0 || ya >= height ) break;
					if (xa < 0) xa = 0;
					int col = p.getSprite().pixels[x + y * p.getSprite().SIZE];
					if(col != ALPHA_COL) pixels[xa + ya * width] = col;
				}
			}
    }

  public void renderTile(int xp, int yp, Tile tile) { //method used to render tile ONLY, xp=x pixels
    xp -= xOffset;
    yp -= yOffset;
    for(int y = 0; y < tile.sprite.SIZE; y++) { //Want to make a universal way of getting size of tiles, since NOT every tile will 16X16 pixels all the time
      int ya =  y + yp;  //absolute position, position relative to the world, from x = 0, y = 0
      for(int x = 0; x < tile.sprite.SIZE; x++) { //Want to make a universal way of getting size of tiles, since NOT every tile will 16X16 pixels all the time
        int xa =  x + xp;
        if(xa < -tile.sprite.SIZE || xa >= width || ya < 0 || ya >= height) break; // If tile exits screen area, stop rendering it, IMPORTANT without this code game can crash
        if(xa < 0) xa = 0; //makes smooth tile render.
        pixels[xa + ya * width] = tile.sprite.pixels[x + y * tile.sprite.SIZE]; //Actually renders sprite to pixels on the screen
      }
    }
  }

  public void renderMob(int xp, int yp, Mob mob) { //used to render soley Mobs(NPCs)
    xp -= xOffset;
    yp -= yOffset;
    for(int y = 0; y < 32; y++) {
      int ya =  y + yp;  //absolute position, position relative to the world, from x = 0, y = 0
      for(int x = 0; x < 32; x++) { //Want to make a universal way of getting size of tiles, since NOT every tile will 16X16 pixels all the time
        int xa =  x + xp;
        if(xa < -32 || xa >= width || ya < 0 || ya >= height) break; // If tile exits screen area, stop rendering it, IMPORTANT without this code game can crash
        if(xa < 0) xa = 0; //makes smooth tile render.
        int col = mob.getSprite().pixels[x + y * 32]; // col is color
        //if((mob instanceof Chaser) && col == 0xff472BBF) col = 0xffBA0015; // Changes color of Chaser mob if found.
        if(col != ALPHA_COL) pixels[xa + ya * width] = col; // if col is the sprite sheet background color it wont render.
        //pixels[xa + ya * width] = sprite.pixels[x + y * 16]; //Actually renders sprite to pixels on the screen
      }
    }
  }

  // USED FOR RENDERING CHARACTER SPRITE IN 1 PIECE with varying(dynamic) size
  public void renderPlayerDynamic(int xp, int yp, Sprite sprite) { //used to render Player/Sprites **AND Mobs
    xp -= xOffset;
    yp -= yOffset;
    for(int y = 0; y < sprite.getHeight(); y++) {
      int ya =  y + yp;  //absolute position, position relative to the world, from x = 0, y = 0
      for(int x = 0; x < sprite.getWidth(); x++) { //Want to make a universal way of getting size of tiles, since NOT every tile will 16X16 pixels all the time
        int xa =  x + xp;
        if(xa < -sprite.getWidth() || xa >= width || ya < 0 || ya >= height) break; // If tile exits screen area, stop rendering it, IMPORTANT without this code game can crash
        if(xa < 0) xa = 0; //makes smooth tile render.
        int col = sprite.pixels[x + y * sprite.getWidth()]; // col is color
        if(col != ALPHA_COL) pixels[xa + ya * width] = col; // if col is the sprite sheet background color it wont render.
        //pixels[xa + ya * width] = sprite.pixels[x + y * 16]; //Actually renders sprite to pixels on the screen
      }
    }
  }


  // USED FOR RENDERING CHARACTER SPRITE IN 1 PIECE
  public void renderPlayer(int xp, int yp, Sprite sprite) { //used to render Player/Sprites **AND Mobs
    xp -= xOffset;
    yp -= yOffset;
    for(int y = 0; y < 32; y++) {
      int ya =  y + yp;  //absolute position, position relative to the world, from x = 0, y = 0
      for(int x = 0; x < 32; x++) { //Want to make a universal way of getting size of tiles, since NOT every tile will 16X16 pixels all the time
        int xa =  x + xp;
        if(xa < -32 || xa >= width || ya < 0 || ya >= height) break; // If tile exits screen area, stop rendering it, IMPORTANT without this code game can crash
        if(xa < 0) xa = 0; //makes smooth tile render.
        int col = sprite.pixels[x + y * 32]; // col is color
        if(col != ALPHA_COL) pixels[xa + ya * width] = col; // if col is the sprite sheet background color it wont render.
        //pixels[xa + ya * width] = sprite.pixels[x + y * 16]; //Actually renders sprite to pixels on the screen
      }
    }
  }
/*  USED FOR RENDERING CHARACTER SPRITE IN 4 PIECES
  public void renderPlayer(int xp, int yp, Sprite sprite) {
    xp -= xOffset;
    yp -= yOffset;
    for(int y = 0; y < 16; y++) {
      int ya =  y + yp;  //absolute position, position relative to the world, from x = 0, y = 0
      for(int x = 0; x < 16; x++) { //Want to make a universal way of getting size of tiles, since NOT every tile will 16X16 pixels all the time
        int xa =  x + xp;
        if(xa < -16 || xa >= width || ya < 0 || ya >= height) break; // If tile exits screen area, stop rendering it, IMPORTANT without this code game can crash
        if(xa < 0) xa = 0; //makes smooth tile render.
        int col = sprite.pixels[x + y * 16]; // col is color
        if( col != 0x000000) pixels[xa + ya * width] = col; // if col is the sprite sheet background color it wont render.
        //pixels[xa + ya * width] = sprite.pixels[x + y * 16]; //Actually renders sprite to pixels on the screen
      }
    }
  }
  */
  
  //Debug rectangle to be drawn
  public void drawRect(int xp, int yp, int width, int height, int color, boolean fixed) {
	  if(fixed) {
	      xp -= xOffset; //makes sprite move with the map
	      yp -= yOffset;
	    }
	  for(int x = xp; x < xp + width; x++) {
		  if(x < 0 | x >= this.width || yp >= this.height) continue; //top part of rectangle
		  if(yp > 0) pixels[x + yp * this.width] = color;
		  if(yp + height >= this.height) continue; 
		  if(yp + height > 0) pixels[x + (yp + height) * this.width] = color;
	  }
	  for(int y = yp; y <= yp + height; y++) {
		  if(xp >= this.width || y < 0 || y >= this.height) continue; //this.width is refering to width of screen not local variable
		  if(xp >= 0) pixels[xp + y * this.width] = color;
		  if(xp + width >= this.width) continue; 
		  if(xp + width > 0) pixels[(xp + width) + y * this.width] = color;
	  }
  }

  public void setOffset(int xOffset, int yOffset) { //method accepts players offset values
    this.xOffset = xOffset;
    this.yOffset = yOffset;
  }

}
