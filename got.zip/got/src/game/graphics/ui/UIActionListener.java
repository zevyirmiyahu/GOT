package game.graphics.ui;

public interface UIActionListener {
	
	public void perform(); //performs desired action
}
