package game.graphics.ui;

import java.awt.Cursor;

public class UIButtonListener {
	
	public static Cursor cursor;
	
	public void entered(UIButton button) { // mouse enters area
		button.setColor(0xa0a0a0); //lighter grey color
		
	}
	
	public void exited(UIButton button) { // mouse exits area
		button.setColor(0x727272); //resets color
	}
	
	public void pressed(UIButton button) { // mouse is clicked down
		button.setColor(0xcc2222);
	}
	
	public void released(UIButton button) {	// mouse is released
		button.setColor(0x727272);
	}	
}
