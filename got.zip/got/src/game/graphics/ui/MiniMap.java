package game.graphics.ui;

import java.awt.Graphics;
import java.awt.Image;
import java.net.URL;

import javax.swing.ImageIcon;

/*
 * Shows player a mini map for navigation
 */
public class MiniMap {
	
	protected int[] tiles; // store entire level as pixel array from pixel map
	protected Image image;
	int xOffset = 0;
	int yOffset = 0;
	
	public MiniMap(String path) {
		try {
			URL imgURL = this.getClass().getResource(path);
			image = new ImageIcon(imgURL).getImage(); 
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void update() {		
	}
	
	public void render(Graphics g) {
		
		int mapWidth = (2 * image.getWidth(null) / 3) + 25; // 200px
		int mapHeight = (2 * image.getHeight(null) / 3) + 25; //133px
		
		g.drawImage(image, 670, 60, mapWidth, mapHeight, null);
	}
}
