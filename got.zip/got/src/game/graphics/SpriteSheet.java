package game.graphics;

import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;


// This class is in charge of any sprite sheets

public class SpriteSheet {
  private String path; // contain path to sprite sheets
  public final int SIZE;
  public final int SPRITE_WIDTH, SPRITE_HEIGHT; //width of the amount of sprites and height of the amount of sprites, NOT width and height of the spritesheet
  private int width, height;
  public int[] pixels;

  // Must use forward slash for the path and specifie size of spritesheet!
  public static SpriteSheet OpeningMenuBackground = new SpriteSheet("/game/res/OpeningScene.png", 128, 71);
  //public static SpriteSheet tiles = new SpriteSheet("/game/res/Fantasy_Character_Sheet.png", 256); //Static, again because only one instnace of it
  public static SpriteSheet items = new SpriteSheet("/game/res/items.png", 160, 240); //sprite sheet with characters. game objects etc
  
  public static SpriteSheet spawn_level = new SpriteSheet("/game/res/spawn_level.png", 64);
  public static SpriteSheet town_level = new SpriteSheet("/game/res/tiles.png", 256); //Contains all needed tiles for town level 
  
  //Buildings
  public static SpriteSheet house = new SpriteSheet("/game/res/house.png", 128);
  public static SpriteSheet farmHouse = new SpriteSheet("/game/res/farmHouse.png", 128);
 
  //Scenery objects
  public static SpriteSheet farmField = new SpriteSheet("/game/res/farmField.png", 64, 80);
  public static SpriteSheet deadChicken = new SpriteSheet("/game/res/chickenDeath.png", 80, 16);
  
  //Used for water animation
  public static SpriteSheet animWater = new SpriteSheet(town_level, 0, 4, 3, 1, 16);
  
  
  //PLAYER SPRITES using animatedsprite class
  public static SpriteSheet player = new SpriteSheet("/game/res/players.png", 192, 512); // obtains spritesheet for automating sprites, in order to simplifuthe code
  public static SpriteSheet player_down = new SpriteSheet(player, 0, 0, 3, 1, 32); // sub-Spritesheets for each direction
  public static SpriteSheet player_up = new SpriteSheet(player, 0, 1, 3, 1, 32);
  public static SpriteSheet player_left = new SpriteSheet(player, 0, 2, 3, 1, 32);
  public static SpriteSheet player_right = new SpriteSheet(player, 0, 3, 3, 1, 32);
  
  //Player swiming sprite
  public static SpriteSheet playerSwimming_down = new SpriteSheet(player, 0, 8, 3, 1, 32);
  public static SpriteSheet playerSwimming_up = new SpriteSheet(player, 0, 9, 3, 1, 32);
  public static SpriteSheet playerSwimming_left = new SpriteSheet(player, 0, 10, 3, 1, 32);
  public static SpriteSheet playerSwimming_right = new SpriteSheet(player, 0, 11, 3, 1, 32);

  
  //Player holding sword sprites
  public static SpriteSheet playerSword_down = new SpriteSheet(player, 3, 4, 3, 1, 32);
  public static SpriteSheet playerSword_up = new SpriteSheet(player, 3, 5, 3, 1, 32);
  public static SpriteSheet playerSword_left = new SpriteSheet(player, 3, 6, 3, 1, 32);
  public static SpriteSheet playerSword_right = new SpriteSheet(player, 3, 7, 3, 1, 32);
  
  //Player standing and swinging sword sprites
  public static SpriteSheet playerAttackStanding_down = new SpriteSheet(player, 3, 8, 3, 1, 32); //Standing sprite attack
  public static SpriteSheet playerAttackStanding_up = new SpriteSheet(player, 3, 9, 3, 1, 32);
  public static SpriteSheet playerAttackStanding_left = new SpriteSheet(player, 3, 10, 3, 1, 32);
  public static SpriteSheet playerAttackStanding_right = new SpriteSheet(player, 3, 11, 3, 1, 32);
  
  //Player moving and swinging sword
  public static SpriteSheet playerAttack_down = new SpriteSheet(player, 3,12, 3, 1, 32); 
  public static SpriteSheet playerAttack_up = new SpriteSheet(player, 3, 13, 3, 1, 32);
  public static SpriteSheet playerAttack_left = new SpriteSheet(player, 3, 14, 3, 1, 32);
  public static SpriteSheet playerAttack_right = new SpriteSheet(player, 3, 15, 3, 1, 32);
  // dummy-NPC SPRITES
  public static SpriteSheet dummy = new SpriteSheet("/game/res/players.png", 192, 512);
  public static SpriteSheet dummy_down = new SpriteSheet(dummy, 0, 4, 3, 1, 32); // sub-Spritesheets for each direction
  public static SpriteSheet dummy_up = new SpriteSheet(dummy, 0, 5, 3, 1, 32);
  public static SpriteSheet dummy_left = new SpriteSheet(dummy, 0, 6, 3, 1, 32);
  public static SpriteSheet dummy_right = new SpriteSheet(dummy, 0, 7, 3, 1, 32);

  // Chaser-NPC SPRITES (Slightly smarter AI implemented) uses A* Algorithm
  public static SpriteSheet chaser = new SpriteSheet("/game/res/players.png", 192, 512);
  public static SpriteSheet chaser_down = new SpriteSheet(chaser, 3, 0, 3, 1, 32); // sub-Spritesheets for each direction
  public static SpriteSheet chaser_up = new SpriteSheet(chaser, 3, 1, 3, 1, 32);
  public static SpriteSheet chaser_left = new SpriteSheet(chaser, 3, 2, 3, 1, 32);
  public static SpriteSheet chaser_right = new SpriteSheet(chaser, 3, 3, 3, 1, 32);

  // Mummy
  public static SpriteSheet mummy = new SpriteSheet("/game/res/mummy.png", 64, 128);
  public static SpriteSheet mummy_down = new SpriteSheet(mummy, 0, 0, 4, 1, 16, 32);
  public static SpriteSheet mummy_up = new SpriteSheet(mummy, 0, 1, 4, 1, 16, 32);
  public static SpriteSheet mummy_left = new SpriteSheet(mummy, 0, 2, 4, 1, 16, 32);
  public static SpriteSheet mummy_right = new SpriteSheet(mummy, 0, 3, 4, 1, 16, 32);
  
  //Goon
  public static SpriteSheet goon = new SpriteSheet("/game/res/goon.png", 128, 192);
  public static SpriteSheet goon_down = new SpriteSheet(goon, 0, 0, 4, 1, 32, 48);
  public static SpriteSheet goon_up = new SpriteSheet(goon, 0, 1, 4, 1, 32, 48);
  public static SpriteSheet goon_left = new SpriteSheet(goon, 0, 2, 4, 1, 32, 48);
  public static SpriteSheet goon_right = new SpriteSheet(goon, 0, 3, 4, 1, 32, 48);
  
  //Pam
  public static SpriteSheet pam = new SpriteSheet("/game/res/pam.png", 112, 128);
  public static SpriteSheet pam_down = new SpriteSheet(pam, 0, 0, 4, 1, 16, 32);
  public static SpriteSheet pam_up = new SpriteSheet(pam, 0, 1, 4, 1, 16, 32);
  public static SpriteSheet pam_left = new SpriteSheet(pam, 0, 2, 4, 1, 16, 32);
  public static SpriteSheet pam_right = new SpriteSheet(pam, 0, 3, 4, 1, 16, 32);
  
  //Chicken
  public static SpriteSheet chicken = new SpriteSheet("/game/res/chicken.png", 48, 144);
  public static SpriteSheet chicken_down = new SpriteSheet(chicken, 0, 0, 3, 1, 16, 32);
  public static SpriteSheet chicken_up = new SpriteSheet(chicken, 0, 1, 3, 1, 16, 32);
  public static SpriteSheet chicken_left = new SpriteSheet(chicken, 0, 2, 3, 1, 16, 32);
  public static SpriteSheet chicken_right = new SpriteSheet(chicken, 0, 3, 3, 1, 16, 32);
  
  //Chicken Death
  public static SpriteSheet chickenDeath = new SpriteSheet("/game/res/chickenDeath.png", 112, 16);
  public static SpriteSheet chicken_dead = new SpriteSheet(chickenDeath, 0, 0, 7, 1, 16, 16);

  
  private Sprite[] sprites; //array of sprites

//FOR NONE SQUARE SPRITES, used like a sub-sheet of Spritesheet, width and height are not in pixel precision, they will be in sprite precision
 public SpriteSheet(SpriteSheet sheet, int x, int y, int width, int height, int spriteWidth, int spriteHeight) { //Constructor
   int xx = x * spriteWidth;
   int yy = y * spriteHeight;
   int w = width * spriteWidth; // this w is in pixel precision because is multipled by the size of the sprites
   int h = height * spriteHeight;
   if(width == height) SIZE = width; // prevents any errors is its a square sprite sheet
   else SIZE = -1; // because it will not be square
   SPRITE_WIDTH = w;
   SPRITE_HEIGHT = h;
   pixels = new int[w * h]; //initialize pixel array
   for(int y0 = 0; y0 < h; y0++) {
     int yp = yy + y0; //yp = y-position, yy = y * spriteSize as above add need to add y0 to run through sprite sheet from current position
     for(int x0 = 0; x0 < w; x0++) { //Used y0 and x0 because x and y parameters are taken by method
       int xp = xx + x0;
       pixels[x0 + y0 * w] = sheet.pixels[xp + yp * sheet.SPRITE_WIDTH];
     }
   }
   int frame = 0; //Need to keep track of frames so can add sprite to that particular frame
   sprites = new Sprite[width * height]; //initialize sprites array
   for(int ya = 0; ya < height; ya++) { //first two for loops used to store pixels into a sprite
     for(int xa = 0; xa < width; xa++) {
       int[] spritePixels = new int[spriteWidth * spriteHeight];
       for(int y0 = 0; y0 < spriteHeight; y0++) { // used to get pixels
         for(int x0 = 0; x0 < spriteWidth; x0++) {
           spritePixels[x0 + y0 * spriteWidth] = pixels[(x0 + xa * spriteWidth) + (y0 + ya * spriteHeight) * SPRITE_WIDTH];
         }
       }
       Sprite sprite = new Sprite(spritePixels, spriteWidth, spriteHeight);
       sprites[frame++] = sprite;
     }
   }
 }

  
  // used like a sub-sheet of Spritesheet, width and height are not in pixel precision, they will be in sprite precision
  public SpriteSheet(SpriteSheet sheet, int x, int y, int width, int height, int spriteSize) { //Constructor
    int xx = x * spriteSize;
    int yy = y * spriteSize;
    int w = width * spriteSize; // this w is in pixel precision because is multipled by the size of the sprites
    int h = height * spriteSize;
    if(width == height) SIZE = width; // prevents any errors is its a square sprite sheet
    else SIZE = -1; // because it will not be square
    SPRITE_WIDTH = w;
    SPRITE_HEIGHT = h;
    pixels = new int[w * h]; //initialize pixel array
    for(int y0 = 0; y0 < h; y0++) {
      int yp = yy + y0; //yp = y-position, yy = y * spriteSize as above add need to add y0 to run through sprite sheet from current position
      for(int x0 = 0; x0 < w; x0++) { //Used y0 and x0 because x and y parameters are taken by method
        int xp = xx + x0;
        pixels[x0 + y0 * w] = sheet.pixels[xp + yp * sheet.SPRITE_WIDTH];
      }
    }
    int frame = 0; //Need to keep track of frames so can add sprite to that particular frame
    sprites = new Sprite[width * height]; //initialize sprites array
    for(int ya = 0; ya < height; ya++) { //first two for loops used to store pixels into a sprite
      for(int xa = 0; xa < width; xa++) {
        int[] spritePixels = new int[spriteSize * spriteSize];
        for(int y0 = 0; y0 < spriteSize; y0++) { // used to get pixels
          for(int x0 = 0; x0 < spriteSize; x0++) {
            spritePixels[x0 + y0 * spriteSize] = pixels[(x0 + xa * spriteSize) + (y0 + ya * spriteSize) * SPRITE_WIDTH];
          }
        }
        Sprite sprite = new Sprite(spritePixels, spriteSize, spriteSize);
        sprites[frame++] = sprite;
      }
    }
  }

  public SpriteSheet(String path, int size) { // Constructor
    this.path = path;
    SIZE = size;
    SPRITE_WIDTH = size;
    SPRITE_HEIGHT = size;
    pixels = new int[SIZE * SIZE];
    load();
  }

  public SpriteSheet(String path, int width, int height) { // Constructor for automating sprites, LOADS NONE SQUARE SPRITE SHEET
    this.path = path;
    SIZE = -1; //since not square, allows to say something wrong.
    SPRITE_WIDTH = width;
    SPRITE_HEIGHT = height;
    pixels = new int[SPRITE_WIDTH * SPRITE_HEIGHT];
    load();
  }

  public Sprite[] getSprites() {
    return sprites;
  }
  
  public int getWidth() {
	  return width;
  }
  
  public int getHeight() {
	  return height;
  }
  
  public int[] getPixels() {
	  return pixels;
  }

  private void load() {
    try {
    	System.out.print("Trying to load: " + path  + "...");
    	BufferedImage image = ImageIO.read(SpriteSheet.class.getResource(path)); //Creates new buffered image, named 'image' and sets it equal to that path
    	System.out.println(" succeeded!");
    	width = image.getWidth(); //width and height of the loaded image
    	height = image.getHeight();
    	pixels = new int[width * height];
    	image.getRGB(0, 0, width, height, pixels, 0, width); //translates the loaded image into pixels for game, avoid using BufferedImage directly in game
    } catch (IOException e) {
        e.printStackTrace();
      } catch(Exception e) {    	  
    	  System.err.println(" failed!");
      }
  }
}
